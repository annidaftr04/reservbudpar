<?php
session_start();
include '../db.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header('Location: login.php');
    exit;
}

date_default_timezone_set('Asia/Jakarta');

// Tangkap data tempat dari POST/GET
$selected_place = $_POST['place_name'] ?? '';
if (isset($_GET['tempat'])) {
    $selected_place = $_GET['tempat'];
}
$selected_date = $_GET['date'] ?? date('Y-m-d');

// Ambil informasi user
$user_id = $_SESSION['user_id'];
$user_query = "SELECT username FROM users WHERE id = ?";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user_data = $user_result->fetch_assoc();
$user_stmt->close();

// ================= PROSES SIMPAN =================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['hari'])) {
    $kode_booking = uniqid('RES-');
    $nama = $_POST['nama'];
    $no_telepon = $_POST['no_telepon'];
    $surat = $_POST['surat'];
    $tempat = $_POST['tempat'];
    $hari = $_POST['hari'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];
    $keterangan = $_POST['keterangan'];
    $status = 'pending';

    // Upload file
    $file_name = null;
    if (isset($_FILES['file_upload']) && $_FILES['file_upload']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/';
        $file_name = uniqid() . '_' . basename($_FILES['file_upload']['name']);
        $target_file = $upload_dir . $file_name;
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        move_uploaded_file($_FILES['file_upload']['tmp_name'], $target_file);
    }

    // Upload KTP
    $ktp_name = null;
    if (isset($_FILES['ktp_upload']) && $_FILES['ktp_upload']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/ktp/';
        $ktp_name = uniqid() . '_' . basename($_FILES['ktp_upload']['name']);
        $target_file = $upload_dir . $ktp_name;
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        move_uploaded_file($_FILES['ktp_upload']['tmp_name'], $target_file);
    }

    // Simpan ke database (udah ada kolom ktp_upload)
    $stmt = $conn->prepare("INSERT INTO reservations 
        (kode_booking, user_id, nama, no_telepon, surat, tempat, hari, jam_mulai, jam_selesai, keterangan, file_upload, ktp_upload, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        "sisssssssssss", 
        $kode_booking, 
        $user_id, 
        $nama, 
        $no_telepon, 
        $surat, 
        $tempat, 
        $hari, 
        $jam_mulai, 
        $jam_selesai, 
        $keterangan, 
        $file_name, 
        $ktp_name,   // ✅ ikut disimpan ke DB
        $status
    );

    if ($stmt->execute()) {
        echo "<script>
            window.onload = function() {
                Swal.fire({
                    title: 'Berhasil!',
                    text: 'Reservasi berhasil diajukan!',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(() => { window.location.href='dashboard.php'; });
            };
        </script>";
    } else {
        echo "<script>
            window.onload = function() {
                Swal.fire('Gagal!', 'Terjadi kesalahan saat mengajukan reservasi.', 'error');
            };
        </script>";
    }
    $stmt->close();
}


// ================= AMBIL TEMPAT =================
$sqlPlaces = "SELECT id, name FROM places";
$resultPlaces = $conn->query($sqlPlaces);

// ================= AMBIL BOOKED DATES =================
$booked_dates = [];
if ($selected_place) {
    $sqlBooked = "SELECT hari FROM reservations WHERE tempat = ? AND status = 'disetujui'";
    $stmtBooked = $conn->prepare($sqlBooked);
    $stmtBooked->bind_param("s", $selected_place);
    $stmtBooked->execute();
    $resultBooked = $stmtBooked->get_result();
    while ($row = $resultBooked->fetch_assoc()) {
        $booked_dates[] = $row['hari'];
    }
}

// ================= FUNCTION KALENDER =================
function build_calendar($month, $year, $booked_dates) {
    $daysOfWeek = ['Sen','Sel','Rab','Kam','Jum','Sab','Min'];
    $firstDayOfMonth = mktime(0,0,0,$month,1,$year);
    $numberDays = date('t',$firstDayOfMonth);
    $dateComponents = getdate($firstDayOfMonth);
    $monthName = strftime('%B',$firstDayOfMonth);
    $dayOfWeek = $dateComponents['wday'];
    if ($dayOfWeek==0) $dayOfWeek=7;

    $calendar = "<div class='calendar mb-4'>";
    $calendar .= "<h5 class='text-center mb-2'>$monthName $year</h5>";
    $calendar .= "<table class='table table-bordered text-center'><thead><tr>";
    foreach ($daysOfWeek as $day) { $calendar .= "<th>$day</th>"; }
    $calendar .= "</tr></thead><tbody><tr>";

    if ($dayOfWeek > 1) {
        for($k=1;$k<$dayOfWeek;$k++){ $calendar .= "<td></td>"; }
    }

    $currentDay=1; $month=str_pad($month,2,"0",STR_PAD_LEFT);
    while ($currentDay <= $numberDays) {
        if ($dayOfWeek > 7) { $dayOfWeek=1; $calendar .= "</tr><tr>"; }
        $currentDayRel = str_pad($currentDay,2,"0",STR_PAD_LEFT);
        $date = "$year-$month-$currentDayRel";
        $isBooked = in_array($date, $booked_dates);
        $isPast = ($date < date('Y-m-d'));

        if ($isBooked) {
            $calendar .= "<td class='booked' data-date='$date'>$currentDay</td>";
        } elseif ($isPast) {
            $calendar .= "<td class='disabled'>$currentDay</td>";
        } else {
            $calendar .= "<td class='available' data-date='$date'>$currentDay</td>";
        }

        $currentDay++; $dayOfWeek++;
    }

    if ($dayOfWeek != 8) {
        for($k=$dayOfWeek;$k<=7;$k++){ $calendar .= "<td></td>"; }
    }
    $calendar .= "</tr></tbody></table></div>";
    return $calendar;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Form Reservasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body { background:#F0F2F5; font-family:'Poppins',sans-serif; }
        .card-reservasi { border-radius:20px; padding:2rem; background:#fff; }
        .calendar td.booked { background:#d6d6d6; cursor:not-allowed; font-weight:bold; }
        .calendar td.disabled { background:#f8f9fa; color:#ccc; cursor:not-allowed; }
        .calendar td.available { cursor:pointer; }
        .calendar td.available:hover { background:#eee; }
        .calendar td.selected { background:#FF5733 !important; color:#fff; font-weight:bold; }
    </style>
</head>
<body>
<div class="container my-5">
    <div class="card card-reservasi">
        <h2 class="text-center mb-3">Formulir Reservasi</h2>
        <form method="POST" enctype="multipart/form-data" class="row g-4">
            <div class="col-md-6">
              <label class="form-label">Nama <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="nama" value="<?= htmlspecialchars($user_data['username']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">No Telepon <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="no_telepon" required>
            </div>
            <div class="col-md-6">
               <label class="form-label">Email <span class="text-danger">*</span></label>
                <input type="email" class="form-control" name="surat" required>
            </div>
            <div class="col-md-6">
               <label class="form-label">Tempat</label>
                <?php if ($selected_place): ?>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($selected_place); ?>" readonly>
                    <input type="hidden" name="tempat" value="<?= htmlspecialchars($selected_place); ?>">
                <?php else: ?>
                    <select name="tempat" class="form-select" required>
                        <option value="">Pilih Tempat</option>
                        <?php while ($places = $resultPlaces->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($places['name']); ?>"><?= htmlspecialchars($places['name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                <?php endif; ?>
            </div>

            <!-- Kalender -->
            <div class="col-md-12">
               <label class="form-label">Tanggal Reservasi <span class="text-danger">*</span></label>
                <input type="hidden" id="hari" name="hari" value="<?= $selected_date; ?>" required>
                <?= build_calendar(date('m'), date('Y'), $booked_dates); ?>
            </div>

          <div class="col-md-6">
                <label class="form-label">Jam Mulai</label>
                <input type="text" class="form-control" value="08:00 WIB" readonly>
                <input type="hidden" name="jam_mulai" value="08:00">
            </div>
            <div class="col-md-6">
                <label class="form-label">Jam Selesai</label>
                <input type="text" class="form-control" value="16:00 WIB" readonly>
                <input type="hidden" name="jam_selesai" value="16:00">
            </div>

            <div class="col-md-6">
              <label class="form-label">Keterangan</label>
                <textarea class="form-control" name="keterangan" rows="3" required></textarea>
            </div>
            <div class="col-md-6">
                <label class="form-label">Upload File <span class="text-danger">*</span></label>
                <input type="file" class="form-control" name="file_upload" required>
            </div>

            <div class="col-md-6">
    <label class="form-label">Upload KTP <span class="text-danger">*</span></label>
    <input type="file" class="form-control" name="ktp_upload" accept="image/*,application/pdf" required>
</div>


            <div class="d-flex justify-content-end mt-4">
                <button type="submit" class="btn btn-primary me-2">Ajukan Reservasi</button>
                <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</div>

<script>
document.querySelectorAll(".calendar td.available").forEach(td => {
    td.addEventListener("click", function() {
        let date = this.getAttribute("data-date");
        document.getElementById("hari").value = date;
        document.querySelectorAll(".calendar td").forEach(el => el.classList.remove("selected"));
        this.classList.add("selected");
    });
});
</script>
</body>
</html>