<?php
include '../db.php';

// Ambil ID tempat dan section dari URL
if (isset($_GET['id'])) {
    $place_id = intval($_GET['id']);
    // Ambil bagian/section dari URL, defaultnya 'all' jika tidak ada
    $section = isset($_GET['section']) ? $_GET['section'] : 'all';

    // Ambil data tempat berdasarkan ID
    $sql = "SELECT * FROM places WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $place_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $place = $result->fetch_assoc();

    // Jika tempat tidak ditemukan
    if (!$place) {
        echo "Tempat tidak ditemukan.";
        exit;
    }

    // --- PERBAIKAN LOGIKA GALERI FOTO ---
    // Ambil semua path gambar dari tabel place_images berdasarkan place_id
    $sql_gallery = "SELECT image_path FROM place_images WHERE place_id = ?";
    $stmt_gallery = $conn->prepare($sql_gallery);
    $stmt_gallery->bind_param("i", $place_id);
    $stmt_gallery->execute();
    $result_gallery = $stmt_gallery->get_result();

    $gallery_images = [];
    while ($row_gallery = $result_gallery->fetch_assoc()) {
        $gallery_images[] = '../' . htmlspecialchars($row_gallery['image_path']);
    }

    // Jika tidak ada gambar galeri, gunakan gambar utama dari tabel places
    if (empty($gallery_images)) {
        $gallery_images[] = '../' . htmlspecialchars($place['image']);
    }

    // Ambil tanggal yang sudah dibooking untuk teater (jika ada)
    $booked_dates_teater = [];
    $sqlBookedTeater = "SELECT hari FROM reservations WHERE tempat = ? AND sub_tempat = 'teater' AND status = 'disetujui'";
    $stmtBookedTeater = $conn->prepare($sqlBookedTeater);
    if ($place['name'] === 'Gedung Seni Budaya') {
        $stmtBookedTeater->bind_param("s", $place['name']);
        $stmtBookedTeater->execute();
        $resultBookedTeater = $stmtBookedTeater->get_result();
        while ($row = $resultBookedTeater->fetch_assoc()) {
            $booked_dates_teater[] = $row['hari'];
        }
    }
    

    // Ambil tanggal yang sudah dibooking untuk lobby (jika ada)
    $booked_dates_lobby = [];
    $sqlBookedLobby = "SELECT hari FROM reservations WHERE tempat = ? AND sub_tempat = 'lobby' AND status = 'disetujui'";
    $stmtBookedLobby = $conn->prepare($sqlBookedLobby);
    if ($place['name'] === 'Gedung Seni Budaya') {
        $stmtBookedLobby->bind_param("s", $place['name']);
        $stmtBookedLobby->execute();
        $resultBookedLobby = $stmtBookedLobby->get_result();
        while ($row = $resultBookedLobby->fetch_assoc()) {
            $booked_dates_lobby[] = $row['hari'];
        }
    }


    // Ambil tanggal yang sudah dibooking untuk tempat biasa (jika bukan Gedung Seni Budaya)
    $booked_dates = [];
    if ($place['name'] !== 'Gedung Seni Budaya') {
        $sqlBooked = "SELECT hari FROM reservations WHERE tempat = ? AND status = 'disetujui'";
        $stmtBooked = $conn->prepare($sqlBooked);
        $stmtBooked->bind_param("s", $place['name']);
        $stmtBooked->execute();
        $resultBooked = $stmtBooked->get_result();
        while ($row = $resultBooked->fetch_assoc()) {
            $booked_dates[] = $row['hari'];
        }
    }


} else {
    echo "ID tempat tidak ditemukan.";
    exit;
}

// Fungsi buat kalender (diperbarui untuk menerima parameter $section)
function build_calendar($month, $year, $booked_dates, $place_name, $place_id, $section) {
    $daysOfWeek = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
    $firstDayOfMonth = mktime(0, 0, 0, $month, 1, $year);
    $numberDays = date('t', $firstDayOfMonth);
    $dateComponents = getdate($firstDayOfMonth);
    $monthName = strftime('%B', $firstDayOfMonth);
    $dayOfWeek = $dateComponents['wday'];
    if ($dayOfWeek == 0) $dayOfWeek = 7;

    $prevMonth = $month - 1;
    $prevYear = $year;
    if ($prevMonth < 1) {
        $prevMonth = 12;
        $prevYear--;
    }

    $nextMonth = $month + 1;
    $nextYear = $year;
    if ($nextMonth > 12) {
        $nextMonth = 1;
        $nextYear++;
    }

    $calendar = "<div class='calendar mb-4'>";
    $calendar .= "<h5 class='text-center mb-2'>";
    $calendar .= "<a class='btn-calendar-nav' href='?id=$place_id&month=$prevMonth&year=$prevYear&section=$section'><i class='fas fa-chevron-left'></i></a>";
    $calendar .= "<span>" . $monthName . " " . $year . "</span>";
    $calendar .= "<a class='btn-calendar-nav' href='?id=$place_id&month=$nextMonth&year=$nextYear&section=$section'><i class='fas fa-chevron-right'></i></a>";
    $calendar .= "</h5>";

    $calendar .= "<table class='table table-bordered text-center'>";
    $calendar .= "<thead><tr>";
    foreach ($daysOfWeek as $day) {
        $calendar .= "<th>$day</th>";
    }
    $calendar .= "</tr></thead><tbody><tr>";

    if ($dayOfWeek > 1) {
        for ($k = 1; $k < $dayOfWeek; $k++) {
            $calendar .= "<td></td>";
        }
    }

    $currentDay = 1;
    $month = str_pad($month, 2, "0", STR_PAD_LEFT);

    while ($currentDay <= $numberDays) {
        if ($dayOfWeek > 7) {
            $dayOfWeek = 1;
            $calendar .= "</tr><tr>";
        }

        $currentDayRel = str_pad($currentDay, 2, "0", STR_PAD_LEFT);
        $date = "$year-$month-$currentDayRel";
        $currentDate = new DateTime($date);
        $now = new DateTime();

        $isBooked = in_array($date, $booked_dates);
        $isDisabled = $currentDate < $now && $date != date('Y-m-d');
        
        $tdClass = '';
        $tdStyle = '';
        $tdAttributes = '';

        if ($isBooked) {
            $tdClass = 'booked';
            $tdAttributes = "title='Tanggal ini sudah direservasi'";
        } elseif ($isDisabled) {
            $tdClass = 'disabled';
            $tdAttributes = "title='Tanggal sudah lewat'";
        } else {
            $tdClass = 'available';
            // Ubah tautan reservasi untuk menyertakan parameter section
            $tdAttributes = "onclick=\"window.location.href='reservasi.php?tempat=" . urlencode($place_name) . "&date=" . urlencode($date) . "&section=" . urlencode($section) . "'\"";
        }
        
        $calendar .= "<td class='$tdClass' $tdAttributes>$currentDay</td>";

        $currentDay++;
        $dayOfWeek++;
    }

    if ($dayOfWeek != 8) {
        for ($k = $dayOfWeek; $k <= 7; $k++) {
            $calendar .= "<td></td>";
        }
    }
    $calendar .= "</tr></tbody></table></div>";
    return $calendar;
}

// Ambil bulan & tahun dari URL (navigasi)
if (isset($_GET['month']) && isset($_GET['year'])) {
    $month = (int)$_GET['month'];
    $year = (int)$_GET['year'];
} else {
    $today = getdate();
    $month = $today['mon'];
    $year = $today['year'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Tempat: <?= htmlspecialchars($place['name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon">
    <style>
        :root {
            --primary-color: #002D62;
            --secondary-color: #F0F2F5;
            --accent-color: #FF5733;
            --card-bg: #FFFFFF;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--secondary-color);
            color: #333;
            padding-top: 2rem;
        }

        .container {
            max-width: 1100px;
        }

        .card-detail {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            padding: 3rem;
            background-color: var(--card-bg);
            margin-bottom: 2rem;
        }

        /* --- Calendar Styling --- */
        .calendar-container {
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            padding: 2rem;
        }
        
        .calendar h5 {
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .calendar h5 span {
            color: var(--primary-color);
        }

        .btn-calendar-nav {
            background-color: transparent;
            border: 1px solid #ddd;
            color: var(--primary-color);
            border-radius: 50%;
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            transition: all 0.2s ease;
        }
        
        .btn-calendar-nav:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .calendar th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 500;
        }
        
        .calendar td {
            height: 60px;
            vertical-align: middle;
            transition: all 0.2s ease;
            cursor: pointer;
        }

        .calendar td.booked {
            background-color: #d6d6d6 !important;
            color: #333 !important;
            font-weight: bold;
            cursor: not-allowed;
            position: relative;
        }
        
        .calendar td.booked .reserved-text {
            display: block;
            font-size: 0.65rem;
            color: #b30000;
            font-weight: 600;
        }

        .calendar td.available:hover {
            background-color: #e9ecef;
        }

        .calendar td.disabled {
            background-color: #f8f9fa;
            color: #ccc;
            cursor: not-allowed;
        }

        .main-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        /* Gaya untuk galeri foto */
        .gallery-thumbnails {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
            justify-content: center;
        }

        .gallery-thumbnails img {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 6px;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.2s ease;
        }

        .gallery-thumbnails img:hover {
            border-color: var(--primary-color);
            transform: scale(1.05);
        }

        .detail-item {
            margin-bottom: 1rem;
            font-size: 1.1rem;
        }

        .detail-item strong {
            display: block;
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 0.25rem;
        }

        .detail-item span {
            color: #555;
        }

        .btn-action {
            padding: 10px 25px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-reservasi { background-color: #FF5733; border-color: #FF5733; color: white; }
        .btn-reservasi:hover { background-color: #D64218; border-color: #D64218; }
        .btn-back { background-color: #6c757d; border-color: #6c757d; color: #fff; }
        .btn-back:hover { background-color: #5a6268; border-color: #5a6268; }

        .modal-content { border-radius: 12px; background-color: #fff; }
        .modal-header { border-bottom: none; }
        .modal-title { font-weight: 600; color: var(--primary-color); }
        .modal-body img { border-radius: 10px; }

        @media(max-width:768px) {
            .sidebar { left: -260px; }
            .sidebar.show { left: 0; }
            .content { margin-left: 0; }
            .navbar, .content { margin-left: 0; }
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center fw-bold text-primary-custom mb-5">Detail Tempat</h2>
        <div class="card-detail">
            <div class="row g-4">
                <?php if ($place['name'] === 'Gedung Seni Budaya'): ?>
                    <div class="col-12">
                        <h4 class="text-center mb-3">Teater</h4>
                        <div class="row g-4">
                            <div class="col-lg-7 text-center">
                                <img src="../assets/img/teater-gedung.jpg" class="main-image" alt="Teater Gedung Seni Budaya">
                                <div class="gallery-thumbnails">
                                    <?php foreach ($gallery_images as $index => $img_path): ?>
                                        <img src="<?= htmlspecialchars($img_path); ?>" class="gallery-thumbnail" data-bs-toggle="modal" data-bs-target="#imageCarouselModal" data-bs-slide-to="<?= $index; ?>" alt="Galeri Foto">
                                    <?php endforeach; ?>
                                </div>
                                <div class="mt-3 text-start">
                                    <p>
                                        Fasilitas teater di Gedung Seni Budaya menawarkan panggung yang luas, pencahayaan profesional, dan sistem suara berkualitas tinggi, cocok untuk pertunjukan drama, konser akustik, dan berbagai acara seni. Dengan kapasitas tempat duduk yang nyaman, teater ini memberikan pengalaman yang imersif bagi para penonton.
                                    </p>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="calendar-container">
                                    <?= build_calendar($month, $year, $booked_dates_teater, $place['name'], $place_id, 'teater'); ?>
                                </div>
                                <div class="d-flex justify-content-center mt-3">
                                    <form action="reservasi.php" method="GET">
                                        <input type="hidden" name="tempat" value="<?= htmlspecialchars($place['name']); ?>">
                                        <input type="hidden" name="section" value="teater">
                                        <button type="submit" class="btn btn-reservasi btn-action"><i class="fas fa-calendar-check me-2"></i>Reservasi Sekarang</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12 mt-5">
                        <hr class="mb-5">
                    </div>

                    <div class="col-12">
                        <h4 class="text-center mb-3">Lobby</h4>
                        <div class="row g-4">
                            <div class="col-lg-7 text-center">
                                <img src="../assets/img/lobby-gedung.jpg" class="main-image" alt="Lobby Gedung Seni Budaya">
                                <div class="gallery-thumbnails">
                                    <?php foreach ($gallery_images as $index => $img_path): ?>
                                        <img src="<?= htmlspecialchars($img_path); ?>" class="gallery-thumbnail" data-bs-toggle="modal" data-bs-target="#imageCarouselModal" data-bs-slide-to="<?= $index; ?>" alt="Galeri Foto">
                                    <?php endforeach; ?>
                                </div>
                                <div class="mt-3 text-start">
                                    <p>
                                        Lobby Gedung Seni Budaya adalah ruang serbaguna yang luas dengan suasana elegan, ideal untuk acara resepsi, pameran seni, atau pertemuan informal. Ruangan ini dilengkapi dengan pencahayaan yang nyaman dan tata letak yang fleksibel, memudahkan penyesuaian untuk berbagai jenis kegiatan.
                                    </p>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="calendar-container">
                                    <?= build_calendar($month, $year, $booked_dates_lobby, $place['name'], $place_id, 'lobby'); ?>
                                </div>
                                <div class="d-flex justify-content-center mt-3">
                                    <form action="reservasi.php" method="GET">
                                        <input type="hidden" name="tempat" value="<?= htmlspecialchars($place['name']); ?>">
                                        <input type="hidden" name="section" value="lobby">
                                        <button type="submit" class="btn btn-reservasi btn-action"><i class="fas fa-calendar-check me-2"></i>Reservasi Sekarang</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-lg-7 text-center">
                        <img id="mainImage" src="../<?= htmlspecialchars($place['image']); ?>" class="main-image" alt="<?= htmlspecialchars($place['name']); ?>">
                        <div class="gallery-thumbnails">
                            <?php foreach ($gallery_images as $index => $img_path): ?>
                                <img src="<?= htmlspecialchars($img_path); ?>" class="gallery-thumbnail" data-bs-toggle="modal" data-bs-target="#imageCarouselModal" data-bs-slide-to="<?= $index; ?>" alt="Galeri Foto">
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="calendar-container">
                            <?= build_calendar($month, $year, $booked_dates, $place['name'], $place_id, $section); ?>
                        </div>
                        <div class="d-flex justify-content-center mt-3">
                            <form action="reservasi.php" method="GET">
                                <input type="hidden" name="tempat" value="<?= htmlspecialchars($place['name']); ?>">
                                <input type="hidden" name="section" value="<?= htmlspecialchars($section); ?>">
                                <button type="submit" class="btn btn-reservasi btn-action"><i class="fas fa-calendar-check me-2"></i>Reservasi Sekarang</button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-12 mt-4">
                    <h3 class="fw-bold text-primary-custom mb-3"><?= htmlspecialchars($place['name']); ?></h3>
                    <ul class="detail-list">
                        <li>
                            <i class="fas fa-info-circle"></i>
                            <strong>Deskripsi</strong><br>
                            <span><?= nl2br(htmlspecialchars($place['description'])); ?></span>
                        </li>
                        <li>
                            <i class="fas fa-map-marker-alt"></i>
                            <strong>Lokasi</strong><br>
                            <span>
                                <a href="<?= htmlspecialchars($place['lokasi']); ?>" target="_blank" class="text-decoration-none text-primary-custom">
                                    Lihat di Google Maps
                                </a>
                            </span>
                        </li>
                    </ul>
                    <div class="d-flex gap-3 mt-4">
                        <a href="index.php#fasilitas" class="btn btn-back btn-action"><i class="fas fa-arrow-left me-2"></i>Kembali</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="imageCarouselModal" tabindex="-1" aria-labelledby="imageCarouselModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageCarouselModalLabel">Galeri Foto</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="imageCarousel" class="carousel slide" data-bs-interval="false">
                        <div class="carousel-indicators">
                            <?php foreach ($gallery_images as $index => $img_path): ?>
                                <button type="button" data-bs-target="#imageCarousel" data-bs-slide-to="<?= $index; ?>" class="<?= $index === 0 ? 'active' : ''; ?>" aria-current="<?= $index === 0 ? 'true' : 'false'; ?>" aria-label="Slide <?= $index + 1; ?>"></button>
                            <?php endforeach; ?>
                        </div>
                        <div class="carousel-inner">
                            <?php foreach ($gallery_images as $index => $img_path): ?>
                                <div class="carousel-item <?= $index === 0 ? 'active' : ''; ?>">
                                    <img src="<?= htmlspecialchars($img_path); ?>" class="d-block w-100 rounded" alt="Galeri Foto">
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#imageCarousel" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#imageCarousel" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const carouselModal = document.getElementById('imageCarouselModal');
            const myCarousel = document.getElementById('imageCarousel');
            
            // Listen for when the modal is about to be shown
            carouselModal.addEventListener('show.bs.modal', function (event) {
                // Get the button that triggered the modal
                const thumbnail = event.relatedTarget;
                const slideIndex = thumbnail.getAttribute('data-bs-slide-to');
                
                // Use Bootstrap's method to go to the correct slide
                const carouselInstance = new bootstrap.Carousel(myCarousel, {
                    interval: false
                });
                carouselInstance.to(slideIndex);
            });
        });
    </script>
</body>
</html>