<?php
session_start();
include '../db.php';

// Ambil data dari tabel places
$sql = "SELECT * FROM places";
$result = $conn->query($sql);
$places = $result->fetch_all(MYSQLI_ASSOC);

// Cek status login
$isLoggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservasi Tempat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="../assets/js/sweetalert.min.js"></script>
    <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-size: cover;
            color: #ffffffff;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: rgba(255, 255, 255, 0.5);
            border-radius: 10px;
            padding: 10px 20px;
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 1000;
        }

        .navbar-nav .nav-link {
            color: black;
            font-weight: bold;
            margin-left: 15px;
            transition: color 0.3s ease;
        }

        .navbar-nav .nav-link.active {
            color: #FF6F61;
        }

        .navbar-nav .nav-link.login {
            background-color: #FF6F61;
            color: white;
            border-radius: 20px;
            padding: 5px 15px;
        }

        .navbar .navbar-brand img {
            max-height: 40px;
        }

        .navbar-toggler {
            border: none;
        }

        .content {
            margin-top: 150px;
            text-align: center;
        }

        .content h1 {
            font-size: 3em;
            font-weight: bold;
        }

        .content p {
            font-size: 1.2em;
        }

        .content .branches {
            margin-top: 20px;
            text-align: left;
            display: inline-block;
        }

        h1 {
            font-weight: bold;
            margin-top: 30px;
            color: #fff;
        }

        .card-container {
            background: url(../assets/img/middle.png);
            background-size: cover;
            border-radius: 15px;
            padding: 20px;
            margin: 40px 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .card {
            margin-top: 20px;
            background: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 15px;
            transition: transform 0.3s, box-shadow 0.3s;
            padding: 20px;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }

        .card-title {
            font-weight: bold;
            color: #333;
        }

        .card-text {
            color: #dcdcdc;
        }

        .card-img-top {
            height: 180px;
            object-fit: cover;
            border-bottom: 2px solid rgba(0, 0, 0, 0.1);
        }

        .btn-primary {
            background-color: #ff8c42;
            border: none;
            border-radius: 20px;
            font-weight: bold;
            padding: 10px 20px;
            transition: background 0.3s, box-shadow 0.3s;
        }

        .btn-primary:hover {
            background-color: #ffa756;
            box-shadow: 0 5px 15px rgba(255, 140, 66, 0.4);
        }

        body {
            padding-top: 80px;
        }

        .contents {
            background-image: url('../assets/img/utama4.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            width: 100%;
            height: 90vh;
            padding-top: 80px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        @media (max-width: 768px) {
            .contents {
                height: 250px;
            }
        }

        @media (max-width: 480px) {
            .contents {
                height: 200px;
            }
        }


        .contents h1 {
            font-size: 48px;
            font-weight: bold;
            color: #000;
            margin-bottom: 20px;
        }

        .contents p {
            font-size: 24px;
            color: #000;
            margin-bottom: 40px;
        }

        .icons {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }

        .icon {
            margin: 0 20px;
            text-align: center;
        }

        .icon img {
            width: 100px;
            height: 100px;
        }

        .icon p {
            font-size: 18px;
            color: #000;
            font-weight: bold;
        }

        .container.text-center {
            background-image: url('../assets/img/middle.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            width: 100vw;
            height: 100%;
            margin: 0;
            padding: 0;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            box-sizing: border-box;
        }

        /* CSS baru untuk footer yang lebih modern */
        .footer-custom {
            background-color: #002D62; /* Warna primer */
            color: #fff;
            padding: 50px 0;
            font-family: 'Poppins', sans-serif;
        }

        .footer-custom h5 {
            font-weight: 600;
            margin-bottom: 25px;
            color: #FFD700; /* Warna kuning emas */
        }

        .footer-custom p {
            font-size: 14px;
            color: #e0e0e0;
        }

        .footer-custom .social-icons a {
            display: inline-block;
            width: 40px;
            height: 40px;
            background-color: #fff;
            color: #002D62;
            border-radius: 50%;
            line-height: 40px;
            text-align: center;
            margin-right: 10px;
            transition: all 0.3s ease;
        }

        .footer-custom .social-icons a:hover {
            transform: translateY(-5px);
            background-color: #FFD700;
            color: #002D62;
        }
        
        .footer-custom .footer-link {
            color: #e0e0e0;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
            transition: color 0.3s ease;
        }

        .footer-custom .footer-link:hover {
            color: #FFD700;
        }

        .footer-custom .copyright {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 13px;
        }

        /* Media Queries for Responsiveness */
        @media (max-width: 1200px) {
            .content h1 {
                font-size: 2.5em;
            }

            .content p {
                font-size: 1.1em;
            }

            .navbar-nav .nav-link {
                font-size: 14px;
            }
        }

        @media (max-width: 768px) {
            .navbar-toggler {
                position: absolute;
                top: 20px;
                right: 20px;
                z-index: 1050;
            }

            .navbar-collapse {
                text-align: center;
                background-color: transparent;
                border-radius: 8px;
                padding: 20px;
                margin-top: 10px;
            }

            .navbar-nav .nav-item {
                margin-bottom: 15px;
            }

            .nav-link {
                font-size: 14px;
                padding: 12px 0;
            }

            .navbar-toggler-icon {
                width: 35px;
                height: 4px;
                background-color: #000;
                border-radius: 2px;
            }

            .navbar {
                margin-bottom: 20px;
            }
        }

        @media (max-width: 576px) {
            .navbar-toggler {
                top: 15px;
                right: 15px;
            }

            .navbar-collapse {
                padding: 25px;
                margin-top: 15px;
                background-color: transparent;
            }

            .navbar-nav .nav-item {
                margin-bottom: 20px;
            }

            .nav-link {
                font-size: 12px;
                padding: 15px 0;
            }
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top bg-transparent">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="../assets/img/logotng.png" alt="Logo Tangerang" 
                     style="height: 45px; width: auto; border-radius: 6px; margin-right: 10px;">
                <img src="../assets/img/kerenjasa.png" alt="Logo keren" 
                     style="height: 45px; width: auto; border-radius: 6px;">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
                    data-bs-target="#navbarNav" aria-controls="navbarNav" 
                    aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="#dashboard">Dashboard</a></li>
                    <li class="nav-item">
                        <?php $isUserLoggedIn = isset($_SESSION['user_id']); ?>
                        <a class="nav-link text-danger" 
                           href="<?= $isUserLoggedIn ? 'reservasi.php' : 'login.php' ?>">Reservasi</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#footer">Contact Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Riwayat</a></li>
                    <?php if ($isUserLoggedIn): ?>
                        <li class="nav-item ms-3"><a class="btn btn-warning" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item ms-3"><a class="btn btn-warning" href="login.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="contents">
    </div>

    <div class="container-fluid py-5 card-container" id="dashboard">
        <div class="row g-4">
            <?php foreach ($places as $place) : ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="card shadow">
                        <img src="../<?= htmlspecialchars($place['image']); ?>" class="card-img-top" alt="<?= htmlspecialchars($place['name']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($place['name']); ?></h5>
                            <a href="detail.php?id=<?= $place['id']; ?>" class="btn btn-primary">Lihat Detail</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <footer class="footer-custom" id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5>About Us</h5>
                    <p>
                        Dinas Kebudayaan dan Pariwisata Kota Tangerang adalah instansi yang berdedikasi untuk melestarikan budaya dan mempromosikan pariwisata di wilayah Tangerang.
                    </p>
                </div>

                <div class="col-md-4 mb-4">
                    <h5>Quick Links</h5>
                    <a href="#" class="footer-link">Home</a>
                    <a href="#dashboard" class="footer-link">Fasilitas</a>
                    <a href="#" class="footer-link">Tentang Kami</a>
                    <a href="#" class="footer-link">Kontak</a>
                </div>

                <div class="col-md-4 mb-4">
                    <h5>Contact Info</h5>
                    <p><i class="fas fa-map-marker-alt me-2"></i>Jl. Mayjen Sutoyo No.11</p>
                    <p><i class="fas fa-phone-alt me-2"></i>0857 2888 6957</p>
                    <p><i class="fas fa-envelope me-2"></i>disbudpar@tangerangkota.go.id</p>
                    <div class="social-icons mt-3">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="text-center copyright">
                &copy; 2024 Reservasi Tempat. All Rights Reserved.
            </div>
        </div>
    </footer>
</body>

</html>