<?php
session_start();
include '../db.php';

// Pastikan hanya user
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: login.php');
    exit;
}

// Ambil parameter tempat
$tempat = isset($_GET['tempat']) ? $_GET['tempat'] : null;

// Ambil daftar tempat
$queryTempat = "SELECT DISTINCT name FROM places";
$resultTempat = $conn->query($queryTempat);
$tempatList = [];
while ($row = $resultTempat->fetch_assoc()) {
    $tempatList[] = $row['name'];
}

// Ambil tanggal booked (hanya yg disetujui)
$booked_dates = [];
$query = "SELECT DISTINCT hari FROM reservations WHERE status = 'disetujui'";
if ($tempat) {
    $query .= " AND tempat = '" . $conn->real_escape_string($tempat) . "'";
}
$result = $conn->query($query);
while ($row = $result->fetch_assoc()) {
    $booked_dates[] = $row['hari'];
}
$booked_dates_json = json_encode($booked_dates);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Kalender Reservasi</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/main.min.css">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/main.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon">
    <style>
        body { background:#F0F2F5; font-family:'Poppins',sans-serif; }
        .fc-event { background:#d6d6d6 !important; border:none !important; color:#333 !important; font-weight:bold; }
        .fc-daygrid-day:hover { background:#f1f1f1; cursor:pointer; }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center mb-4">Kalender Reservasi</h2>
    <div class="mb-3">
        <label for="filterTempat" class="form-label">Filter Berdasarkan Tempat:</label>
        <select id="filterTempat" class="form-select">
            <option value="">Semua Tempat</option>
            <?php foreach ($tempatList as $t): ?>
                <option value="<?= htmlspecialchars($t); ?>" <?= ($tempat === $t) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($t); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <a href="dashboard.php" class="btn btn-secondary mb-3">Kembali</a>
    <div id="calendar"></div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var bookedDates = <?= $booked_dates_json; ?>;
    var filterTempat = document.getElementById('filterTempat');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek'
        },
        events: bookedDates.map(date => ({
            title: 'Sudah Terisi',
            start: date,
            color: '#d6d6d6'
        })),
        dateClick: function(info) {
            if (bookedDates.includes(info.dateStr)) return; // skip kalau booked
            var selectedTempat = filterTempat.value;
            if (!selectedTempat) {
                alert('Pilih tempat terlebih dahulu!');
                return;
            }
            window.location.href = 'reservasi.php?date=' + info.dateStr + '&tempat=' + encodeURIComponent(selectedTempat);
        }
    });

    calendar.render();

    // Filter tempat
    filterTempat.addEventListener('change', function() {
        var tempat = this.value;
        var urlParams = new URLSearchParams(window.location.search);
        if (tempat) urlParams.set('tempat', tempat);
        else urlParams.delete('tempat');
        window.location.search = urlParams.toString();
    });
});
</script>
</body>
</html>