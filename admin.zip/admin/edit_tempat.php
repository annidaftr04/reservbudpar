<?php
include '../db.php';
session_start();

// Pastikan admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

// Ambil Data Tempat Berdasarkan ID
$id = $_GET['id'] ?? null;

if (!$id || !is_numeric($id)) {
    echo "ID tidak valid.";
    exit;
}

// Ambil data tempat utama
$stmt_place = $conn->prepare("SELECT * FROM places WHERE id = ?");
$stmt_place->bind_param("i", $id);
$stmt_place->execute();
$result_place = $stmt_place->get_result();
$place = $result_place->fetch_assoc();
$stmt_place->close();

// Ambil data galeri foto
$stmt_images = $conn->prepare("SELECT * FROM place_images WHERE place_id = ?");
$stmt_images->bind_param("i", $id);
$stmt_images->execute();
$result_images = $stmt_images->get_result();
$images = $result_images->fetch_all(MYSQLI_ASSOC);
$stmt_images->close();

if (!$place) {
    echo "Data tempat tidak ditemukan.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Tempat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: #002D62; /* Navy Blue */
            --secondary-color: #C1E1FF; /* Light Blue */
            --accent-color: #FF5733; /* Orange Red */
            --bg-color: #F8F9FA;
            --card-bg: #FFFFFF;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-color);
            color: #333;
        }

        .container {
            max-width: 900px;
        }

        .card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            padding: 3rem;
            background-color: var(--card-bg);
        }
        
        h1 {
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 2rem;
            text-align: center;
        }

        .form-label {
            font-weight: 500;
            color: var(--primary-color);
        }

        .form-control {
            border-radius: 12px;
            border: 1px solid #ddd;
            padding: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(255, 87, 51, 0.25);
        }
        
        .section-divider {
            margin-top: 2.5rem;
            margin-bottom: 2.5rem;
            border-top: 2px solid #EEE;
        }

        .image-upload-container, .gallery-container {
            border: 2px dashed #D1D9E1;
            border-radius: 12px;
            padding: 2rem;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
        }

        .image-upload-container:hover, .gallery-container:hover {
            background-color: #F3F6F9;
        }
        
        .image-preview {
            max-width: 100%;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .gallery-item {
            position: relative;
            aspect-ratio: 1 / 1;
            overflow: hidden;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .gallery-item:hover img {
            transform: scale(1.05);
        }

        .delete-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: var(--accent-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            font-size: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.9;
            transition: opacity 0.3s ease;
            z-index: 10;
        }
        
        .delete-btn:hover {
            opacity: 1;
            transform: scale(1.1);
        }

        .btn-action {
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #1A4D90;
            border-color: #1A4D90;
        }

        .btn-outline-secondary {
            color: #6C757D;
            border-color: #6C757D;
        }
        
        .btn-outline-secondary:hover {
            background-color: #6C757D;
            color: white;
        }
    </style>
</head>

<body>
    <div class="container my-5">
        <div class="card">
            <h1>Edit Tempat</h1>

            <form action="update_tempat.php" method="POST" enctype="multipart/form-data" id="editForm">
                <input type="hidden" name="id" value="<?= htmlspecialchars($place['id']); ?>">
                
                <div class="row g-4">
                    <div class="col-lg-6">
                        <div class="form-group mb-4">
                            <label for="placeName" class="form-label">Nama Tempat</label>
                            <input type="text" class="form-control" id="placeName" name="name" value="<?= htmlspecialchars($place['name']); ?>" required>
                        </div>
                        <div class="form-group mb-4">
                            <label for="placeLokasi" class="form-label">Lokasi (URL)</label>
                            <textarea class="form-control" id="placeLokasi" name="lokasi" rows="3" required><?= htmlspecialchars($place['lokasi']); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group mb-4">
                            <label for="placeDescription" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="placeDescription" name="description" rows="5" required><?= htmlspecialchars($place['description']); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="section-divider"></div>

                <h4 class="fw-bold text-center mb-4">Gambar Utama</h4>
                <div class="image-upload-container mb-5">
                    <div class="row justify-content-center align-items-center g-4">
                        <div class="col-md-6 text-center">
                            <label for="placeImage" class="form-label d-block text-muted mb-3">
                                <i class="fas fa-camera fa-2x mb-2"></i><br>Pilih Gambar Utama Baru
                            </label>
                            <input type="file" class="form-control d-none" id="placeImage" name="image" accept=".jpg,.jpeg,.png,.gif">
                        </div>
                        <div class="col-md-6">
                            <p class="fw-bold mb-2">Gambar Saat Ini:</p>
                            <img src="../<?= htmlspecialchars($place['image']); ?>" alt="Gambar Utama" class="image-preview" id="mainImagePreview">
                        </div>
                    </div>
                </div>

                <div class="section-divider"></div>

                <h4 class="fw-bold text-center mb-4">Galeri Foto</h4>
                <div class="gallery-upload-container gallery-container mb-4">
                    <p class="text-muted mb-4">Unggah foto baru ke galeri:</p>
                    <label for="new_images" class="form-label d-block mb-3">
                        <i class="fas fa-plus-circle fa-2x text-primary mb-2"></i><br>Pilih Foto
                    </label>
                    <input type="file" class="form-control d-none" id="new_images" name="new_images[]" multiple accept="image/*">
                </div>
                
                <div id="gallery-preview-container" class="row row-cols-2 row-cols-md-3 g-4 mb-5">
                    <?php if (empty($images)): ?>
                        <div class="col-12 text-center text-muted">Belum ada foto galeri.</div>
                    <?php else: ?>
                        <?php foreach ($images as $image): ?>
                            <div class="col">
                                <div class="gallery-item">
                                    <img src="../<?= htmlspecialchars($image['image_path']); ?>" alt="Galeri">
                                    <a href="delete_image.php?id=<?= $image['id']; ?>&place_id=<?= $id; ?>" class="delete-btn" onclick="return confirm('Apakah Anda yakin ingin menghapus foto ini?');">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <div class="d-flex justify-content-end gap-3">
                    <button type="submit" class="btn btn-primary btn-action"><i class="fas fa-save me-2"></i>Simpan Perubahan</button>
                    <a href="kelola_tempat.php" class="btn btn-outline-secondary btn-action"><i class="fas fa-times-circle me-2"></i>Batal</a>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Real-time preview for the main image
        document.getElementById('placeImage').addEventListener('change', function() {
            const previewImage = document.getElementById('mainImagePreview');
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                }
                reader.readAsDataURL(this.files[0]);
            }
        });

        // Real-time preview for gallery images
        document.getElementById('new_images').addEventListener('change', function(event) {
            const previewContainer = document.getElementById('gallery-preview-container');
            
            // Hapus pesan "Belum ada foto galeri" jika ada
            const noPhotosMessage = previewContainer.querySelector('.col-12');
            if (noPhotosMessage) {
                noPhotosMessage.remove();
            }

            for (const file of event.target.files) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const colDiv = document.createElement('div');
                    colDiv.classList.add('col');
                    colDiv.innerHTML = `
                        <div class="gallery-item">
                            <img src="${e.target.result}" alt="Pratinjau Galeri">
                            <button type="button" class="delete-btn" onclick="this.closest('.col').remove();">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    `;
                    previewContainer.appendChild(colDiv);
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>