<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login_admin.php');
    exit;
}

if (isset($_GET['id']) && isset($_GET['action'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    if ($action == 'approve') {
        $query = "UPDATE reservations SET status='disetujui' WHERE id='$id'";
        if ($conn->query($query)) {
            echo "<script>
                    swal('Berhasil', 'Reservasi telah disetujui!', 'success')
                        .then(() => window.location.href = 'dashboard_admin.php');
                  </script>";
        }
    } elseif ($action == 'delete') {
        $query = "DELETE FROM reservations WHERE id='$id'";
        if ($conn->query($query)) {
            echo "<script>
                    swal('Berhasil', 'Reservasi telah dihapus!', 'success')
                        .then(() => window.location.href = 'dashboard_admin.php');
                  </script>";
        }
    }
} else {
    header('Location: dashboard.php');
}
?>
