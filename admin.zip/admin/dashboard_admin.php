<?php
include '../db.php';
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

// Pastikan variabel koneksi database `$conn` digunakan
if (!isset($conn)) {
    die("Koneksi database tidak ditemukan.");
}

// Cek apakah data admin tersedia di sesi
$admin = isset($_SESSION['admin_data']) ? $_SESSION['admin_data'] : ['username' => 'Admin'];

// Query untuk mendapatkan status dan jumlah dari tabel `reservations`
$query = "SELECT status, COUNT(*) as count FROM reservations GROUP BY status";
$result = $conn->query($query);

// --- Hitung statistik ----------------------------------------------------
$statusCounts = [
    'Disetujui' => 0,
    'Ditolak'   => 0,
    'Pending'   => 0,
];

$statStmt = $conn->query("SELECT status, COUNT(*) AS total FROM reservations GROUP BY status");
while ($row = $statStmt->fetch_assoc()) {
    $key = ucfirst(strtolower($row['status']));
    if (isset($statusCounts[$key])) {
        $statusCounts[$key] = (int) $row['total'];
    }
}

$totalReservasi = array_sum($statusCounts);
$totalApproved  = $statusCounts['Disetujui'];
$totalRejected  = $statusCounts['Ditolak'];
$totalPending   = $statusCounts['Pending'];

$labelsJSON = json_encode(array_keys($statusCounts));
$dataJSON   = json_encode(array_values($statusCounts));

// Siapkan array untuk data status dan jumlahnya
$data = [];
$labels = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $labels[] = $row['status'];
        $data[] = $row['count'];
    }
}
$conn->close();

// Encode data untuk digunakan di JavaScript
$labelsJSON = json_encode($labels);
$dataJSON = json_encode($data);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard Admin</title>
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta http-equiv="pragma" content="no-cache">
    
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --navy: #1C2B36;
            --navy-dark: #151E27;
            --accent: #FFD43B;
            --gray-light: #f4f6fb;
            --gray-dark: #6c757d;
            --sidebar-width: 260px;
            --sidebar-collapsed: 80px;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--gray-light);
            overflow-x: hidden;
            transition: margin-left .3s;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Montserrat', sans-serif;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--navy) 0%, var(--navy-dark) 100%);
            color: #fff;
            padding: 20px 0;
            transition: width .3s, left .3s;
            z-index: 1040;
            display: flex;
            flex-direction: column;
        }

        .sidebar.collapsed {
            width: var(--sidebar-collapsed);
        }

        .sidebar-header {
            text-align: center;
            padding: 10px 0 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        .sidebar-header h5 {
            font-weight: 600;
            transition: opacity 0.3s;
        }

        .sidebar.collapsed .sidebar-header h5 {
            opacity: 0;
        }

        .sidebar-header img {
            max-height: 40px;
        }

        .sidebar-nav a {
            color: #fff;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 22px;
            text-decoration: none !important;
            border-radius: 6px;
            margin: 4px 10px;
            font-weight: 500;
            white-space: nowrap;
            transition: background .2s, transform .2s;
        }

        .sidebar-nav a i {
            min-width: 22px;
            text-align: center;
            font-size: 1rem;
        }

        .sidebar.collapsed .sidebar-nav a span {
            display: none;
        }

        .sidebar-nav a.active,
        .sidebar-nav a:hover {
            background-color: rgba(255, 212, 59, 0.1);
            color: var(--accent);
            transform: translateX(5px);
        }

        .sidebar-nav a.active {
            border-left: 3px solid var(--accent);
            padding-left: 19px;
        }

        /* Navbar */
        .navbar {
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            height: 60px;
            transition: margin-left .3s;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1030;
        }

        .navbar-brand {
            color: var(--navy) !important;
            font-weight: 600;
            font-size: 1.25rem;
        }
        
        .btn-outline-dark {
            border-color: #ddd !important;
            color: #333 !important;
        }

        /* Content */
        .content {
            margin-left: var(--sidebar-width);
            padding: 80px 2.5rem 4rem;
            transition: margin-left .3s;
        }

        body.sidebar-collapsed .navbar {
            margin-left: var(--sidebar-collapsed);
        }

        body.sidebar-collapsed .content {
            margin-left: var(--sidebar-collapsed);
        }
        
        .card-shadow {
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card-shadow:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }

        .card-body {
            padding: 2rem;
        }

        .widget-icon {
            font-size: 2.5rem;
            width: 60px;
            height: 60px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            color: white;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }

        .widget-icon.bg-primary-dark { background-color: #002147; }
        .widget-icon.bg-success-dark { background-color: #198754; }
        .widget-icon.bg-danger-dark { background-color: #dc3545; }
        
        .widget-card h5 {
            font-weight: 600;
        }
        
        .widget-card h2 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 800;
        }

        .chart-wrapper {
            position: relative;
            height: 360px;
        }

        @media(max-width:768px) {
            .sidebar {
                left: -260px;
            }
            .sidebar.show {
                left: 0;
            }
            .navbar, .content {
                margin-left: 0;
            }
            .widget-card {
                flex-direction: column;
            }
            .widget-icon {
                margin: auto;
                margin-bottom: 1rem;
            }
        }
    </style>
</head>

<body>
    <aside id="sidebar" class="sidebar">
        <div class="sidebar-header">
            <img src="../assets/img/logotng.png" alt="Logo">
            <h5 class="mt-2">Dashboard Admin</h5>
        </div>
        <div class="sidebar-nav">
            <a href="dashboard_admin.php" class="active"><i class="fas fa-home"></i> <span>Dashboard</span></a>
            <a href="kelola_reserv.php"><i class="fas fa-table"></i> <span>Data Reservasi</span></a>
            <a href="kelola_tempat.php"><i class="fas fa-map-marker-alt"></i> <span>Kelola Tempat</span></a>
            <a href="calendar.php"><i class="fas fa-calendar-alt"></i> <span>Kalender</span></a>
            <a href="logout_admin.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>
    </aside>

    <nav class="navbar">
        <div class="container-fluid px-4">
            <button id="sidebarToggle" class="btn btn-sm btn-outline-dark d-lg-none" title="Menu"><i class="fas fa-bars"></i></button>
            <span class="navbar-brand d-none d-lg-block fw-semibold">Dashboard Admin</span>
            <div class="d-flex align-items-center gap-2 ms-auto">
                <button id="fullscreenToggle" class="btn btn-sm btn-outline-dark" title="Fullscreen"><i class="fas fa-expand"></i></button>
            </div>
        </div>
    </nav>

    <main class="content">
        <h1 class="h3 fw-bold mb-4">Selamat Datang, Admin!</h1>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card card-shadow h-100">
                    <div class="card-body d-flex align-items-center widget-card">
                        <div class="widget-icon bg-primary-dark me-4">
                            <i class="fas fa-list-alt"></i>
                        </div>
                        <div>
                            <h5 class="text-muted text-uppercase mb-1">Total Reservasi</h5>
                            <h2 class="fw-bold mb-0"><?= $totalReservasi; ?></h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-shadow h-100">
                    <div class="card-body d-flex align-items-center widget-card">
                        <div class="widget-icon bg-success-dark me-4">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div>
                            <h5 class="text-muted text-uppercase mb-1">Disetujui</h5>
                            <h2 class="fw-bold mb-0"><?= $totalApproved; ?></h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-shadow h-100">
                    <div class="card-body d-flex align-items-center widget-card">
                        <div class="widget-icon bg-danger-dark me-4">
                            <i class="fas fa-times-circle"></i>
                        </div>
                        <div>
                            <h5 class="text-muted text-uppercase mb-1">Ditolak</h5>
                            <h2 class="fw-bold mb-0"><?= $totalRejected; ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <div class="card card-shadow">
                    <div class="card-header bg-white fw-semibold">Statistik Reservasi</div>
                    <div class="card-body chart-wrapper">
                        <canvas id="reservChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Sidebar toggle
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const fullscreenToggle = document.getElementById('fullscreenToggle');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                const isMobile = window.matchMedia('(max-width: 768px)').matches;
                if (isMobile) {
                    sidebar.classList.toggle('show');
                } else {
                    document.body.classList.toggle('sidebar-collapsed');
                }
            });
        }

        if (fullscreenToggle) {
            fullscreenToggle.addEventListener('click', () => {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-compress"></i>';
                } else {
                    document.exitFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-expand"></i>';
                }
            });
        }

        document.addEventListener('click', e => {
            const isMobile = window.matchMedia('(max-width: 768px)').matches;
            if (isMobile && sidebar.classList.contains('show') && !sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        });

        // Data PHP ke JS
        const labels = <?= $labelsJSON; ?>;
        const dataStatus = <?= $dataJSON; ?>;

        const bgColors = [
            '#198754',
            '#dc3545',
            '#0d6efd'
        ];

        const ctx = document.getElementById('reservChart');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: dataStatus,
                    backgroundColor: bgColors,
                    hoverOffset: 6,
                    borderWidth: 1,
                    borderColor: '#fff',
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 18,
                            usePointStyle: true,
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: context => `${context.label}: ${context.formattedValue} reservasi`
                        }
                    }
                },
                animation: {
                    animateScale: true
                }
            }
        });
    </script>
</body>

</html>