<?php
include '../db.php';
session_start();

// Pastikan admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

$message = "";

/* ============ PROSES FORM ============ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name        = trim($_POST['name']);
    $description = trim($_POST['description']);
    $lokasi      = trim($_POST['lokasi']);
    $imagePath   = ''; 
    $upload_success = false;

    // Cek apakah ada gambar utama yang diunggah
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowedExt  = ['jpg', 'jpeg', 'png', 'gif'];
        $ext         = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $allowedExt)) {
            $message = "File gambar utama harus berupa JPG, JPEG, PNG, atau GIF.";
        } else {
            $uploadDir = __DIR__ . '/../assets/img/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $imageName = uniqid('img_', true) . '.' . $ext;
            $target    = $uploadDir . $imageName;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                $imagePath = 'assets/img/' . $imageName;
                $upload_success = true;
            } else {
                $message = "Gagal mengunggah gambar utama.";
            }
        }
    } else {
        $message = "Silakan pilih gambar utama.";
    }

    // Simpan data tempat ke database jika unggahan berhasil
    if ($upload_success && $name && $description && $lokasi) {
        $stmt_place = $conn->prepare(
            "INSERT INTO places (name, description, image, lokasi) VALUES (?, ?, ?, ?)"
        );
        $stmt_place->bind_param("ssss", $name, $description, $imagePath, $lokasi);

        if ($stmt_place->execute()) {
            $new_place_id = $conn->insert_id; // Ambil ID tempat yang baru dibuat

            // Proses unggahan galeri foto
            if (isset($_FILES['gallery_images'])) {
                $gallery_files = $_FILES['gallery_images'];
                $gallery_upload_dir = __DIR__ . '/../assets/img/';

                foreach ($gallery_files['tmp_name'] as $key => $tmp_name) {
                    if ($gallery_files['error'][$key] === UPLOAD_ERR_OK) {
                        $gallery_ext = strtolower(pathinfo($gallery_files['name'][$key], PATHINFO_EXTENSION));
                        if (in_array($gallery_ext, ['jpg', 'jpeg', 'png', 'gif'])) {
                            $gallery_image_name = uniqid('gallery_', true) . '.' . $gallery_ext;
                            $gallery_target = $gallery_upload_dir . $gallery_image_name;

                            if (move_uploaded_file($tmp_name, $gallery_target)) {
                                $gallery_image_path = 'assets/img/' . $gallery_image_name;
                                $stmt_gallery = $conn->prepare("INSERT INTO place_images (place_id, image_path) VALUES (?, ?)");
                                $stmt_gallery->bind_param("is", $new_place_id, $gallery_image_path);
                                $stmt_gallery->execute();
                                $stmt_gallery->close();
                            }
                        }
                    }
                }
            }

            header('Location: kelola_tempat.php');
            exit;
        } else {
            $message = "Gagal menambahkan tempat: " . $conn->error;
        }
        $stmt_place->close();
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Tempat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: #002D62;
            --secondary-color: #F0F2F5;
            --accent-color: #FF5733;
            --card-bg: #FFFFFF;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--secondary-color);
            color: #333;
        }

        .container {
            max-width: 900px;
        }

        .card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            padding: 3rem;
            background-color: var(--card-bg);
        }

        h1 {
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 2rem;
            text-align: center;
        }
        
        h4 {
            font-weight: 600;
            color: var(--primary-color);
            margin-top: 2rem;
            margin-bottom: 1rem;
        }

        .form-label {
            font-weight: 500;
            color: var(--primary-color);
        }

        .form-control {
            border-radius: 12px;
            border: 1px solid #ddd;
            padding: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(255, 87, 51, 0.25);
        }

        .image-preview-container {
            border: 2px dashed #D1D9E1;
            border-radius: 12px;
            padding: 2rem;
            text-align: center;
            margin-top: 1.5rem;
            background-color: #fcfcfc;
        }
        
        .image-preview-container img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .btn-action {
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #1A4D90;
            border-color: #1A4D90;
        }

        .btn-secondary {
            background-color: #6C757D;
            border-color: #6C757D;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }

        .section-divider {
            border-top: 1px solid #ddd;
            margin: 2rem 0;
        }
    </style>
</head>

<body>
    <div class="container my-5">
        <div class="card">
            <h1>Tambah Tempat Baru</h1>

            <?php if ($message): ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <form method="post" enctype="multipart/form-data" id="addPlaceForm">
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Tempat</label>
                            <input type="text" id="name" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Deskripsi</label>
                            <textarea id="description" name="description" rows="5" class="form-control" required></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="lokasi" class="form-label">Lokasi</label>
                            <textarea id="lokasi" name="lokasi" rows="5" class="form-control" required></textarea>
                        </div>
                    </div>
                </div>

                <div class="section-divider"></div>

                <h4 class="text-center">Unggah Gambar Utama & Galeri</h4>
                <p class="text-muted text-center mb-4">Tambahkan gambar utama dan beberapa foto untuk galeri.</p>

                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="image" class="form-label">Gambar Utama</label>
                            <input type="file" id="image" name="image" class="form-control" accept=".jpg,.jpeg,.png,.gif" required>
                        </div>
                        <div class="image-preview-container d-none">
                            <p class="text-muted mb-2"><i class="fas fa-image me-1"></i>Pratinjau Gambar Utama</p>
                            <img id="image-preview" src="#" alt="Pratinjau Gambar Utama">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="gallery_images" class="form-label">Galeri Foto</label>
                            <input type="file" id="gallery_images" name="gallery_images[]" class="form-control" accept=".jpg,.jpeg,.png,.gif" multiple>
                            <small class="form-text text-muted">Anda dapat memilih lebih dari satu foto.</small>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-3 mt-4">
                    <button type="button" class="btn btn-primary btn-action" onclick="confirmAdd()"><i class="fas fa-plus me-2"></i>Tambah Tempat</button>
                    <a href="kelola_tempat.php" class="btn btn-secondary btn-action"><i class="fas fa-times me-2"></i>Batal</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        function confirmAdd() {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: 'Data tempat akan ditambahkan!',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, tambahkan!',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#002D62',
                cancelButtonColor: '#6C757D'
            }).then((r) => {
                if (r.isConfirmed) document.getElementById('addPlaceForm').submit();
            });
        }

        // Real-time image preview for the main image
        document.getElementById('image').addEventListener('change', function(event) {
            const [file] = event.target.files;
            if (file) {
                const previewContainer = document.querySelector('.image-preview-container');
                const previewImage = document.getElementById('image-preview');
                previewImage.src = URL.createObjectURL(file);
                previewContainer.classList.remove('d-none');
            }
        });
    </script>
</body>

</html>