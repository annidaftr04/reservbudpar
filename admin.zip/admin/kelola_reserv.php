<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

include '../db.php';

// Inisialisasi variabel pencarian
$kode_booking_search = isset($_GET['kode_booking']) ? $_GET['kode_booking'] : '';
$nama_search = isset($_GET['nama']) ? $_GET['nama'] : '';
$hari_search = isset($_GET['hari']) ? $_GET['hari'] : '';
$tempat_search = isset($_GET['tempat']) ? $_GET['tempat'] : '';
$status_search = isset($_GET['status']) ? $_GET['status'] : '';

// Pagination setup
$items_per_page = 8;
$current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($current_page - 1) * $items_per_page;

// Query untuk mengambil data berdasarkan pencarian, dengan limit dan offset
$query = "SELECT * FROM reservations 
          WHERE (kode_booking LIKE ? OR ? = '') 
          AND (nama LIKE ? OR ? = '') 
          AND (hari LIKE ? OR ? = '') 
          AND (tempat LIKE ? OR ? = '')
          AND (status LIKE ? OR ? = '')
          ORDER BY id DESC 
          LIMIT ? OFFSET ?";

$stmt = $conn->prepare($query);
$search_kode_booking = "%$kode_booking_search%";
$search_nama = "%$nama_search%";
$search_hari = "%$hari_search%";
$search_tempat = "%$tempat_search%";
$search_status = "%$status_search%";
$stmt->bind_param(
    "ssssssssssii",
    $search_kode_booking,
    $kode_booking_search,
    $search_nama,
    $nama_search,
    $search_hari,
    $hari_search,
    $search_tempat,
    $tempat_search,
    $search_status,
    $status_search,
    $items_per_page,
    $offset
);
$stmt->execute();
$result = $stmt->get_result();

// Query untuk menghitung total data
$count_query = "SELECT COUNT(*) AS total FROM reservations 
                WHERE (kode_booking LIKE ? OR ? = '') 
                AND (nama LIKE ? OR ? = '') 
                AND (hari LIKE ? OR ? = '') 
                AND (tempat LIKE ? OR ? = '')
                AND (status LIKE ? OR ? = '')";

$count_stmt = $conn->prepare($count_query);
$count_stmt->bind_param(
    "ssssssssss",
    $search_kode_booking,
    $kode_booking_search,
    $search_nama,
    $nama_search,
    $search_hari,
    $hari_search,
    $search_tempat,
    $tempat_search,
    $search_status,
    $status_search
);
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_data = $count_result->fetch_assoc()['total'];

$total_pages = ceil($total_data / $items_per_page);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kelola Reservasi</title>
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta http-equiv="pragma" content="no-cache">
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon" />
    <style>
        :root {
            --navy: #1C2B36;
            --navy-dark: #151E27;
            --accent: #FFD43B;
            --gray-light: #f4f6fb;
            --gray-dark: #6c757d;
            --sidebar-width: 260px;
            --sidebar-collapsed: 80px;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--gray-light);
            overflow-x: hidden;
            transition: margin-left .3s;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--navy) 0%, var(--navy-dark) 100%);
            color: #fff;
            padding: 20px 0;
            transition: width .3s, left .3s;
            z-index: 1040;
            display: flex;
            flex-direction: column;
        }

        .sidebar.collapsed {
            width: var(--sidebar-collapsed);
        }

        .sidebar-header {
            text-align: center;
            padding: 10px 0 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        .sidebar-header h5 {
            font-weight: 600;
            transition: opacity 0.3s;
        }

        .sidebar.collapsed .sidebar-header h5 {
            opacity: 0;
        }

        .sidebar-header img {
            max-height: 40px;
        }

        .sidebar-nav a {
            color: #fff;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 22px;
            text-decoration: none !important;
            border-radius: 6px;
            margin: 4px 10px;
            font-weight: 500;
            white-space: nowrap;
            transition: background .2s, transform .2s;
        }

        .sidebar-nav a i {
            min-width: 22px;
            text-align: center;
            font-size: 1rem;
        }

        .sidebar.collapsed .sidebar-nav a span {
            display: none;
        }

        .sidebar-nav a.active,
        .sidebar-nav a:hover {
            background-color: rgba(255, 212, 59, 0.1);
            color: var(--accent);
            transform: translateX(5px);
        }

        .sidebar-nav a.active {
            border-left: 3px solid var(--accent);
            padding-left: 19px;
        }

        /* Navbar */
        .navbar {
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            height: 60px;
            transition: margin-left .3s;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1030;
        }

        .navbar-brand {
            color: var(--navy) !important;
            font-weight: 600;
            font-size: 1.25rem;
        }
        
        .btn-outline-dark {
            border-color: #ddd !important;
            color: #333 !important;
        }

        /* Content */
        .content {
            margin-left: var(--sidebar-width);
            padding: 80px 2.5rem 4rem;
            transition: margin-left .3s;
        }

        body.sidebar-collapsed .navbar {
            margin-left: var(--sidebar-collapsed);
        }

        body.sidebar-collapsed .content {
            margin-left: var(--sidebar-collapsed);
        }

        /* Card & Table */
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .05);
        }
        
        .card-body {
            padding: 2.5rem;
        }

        .card-header {
            background: transparent;
            border-bottom: none;
            padding: 0 0 1.5rem 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h5 {
            font-weight: 600;
            color: var(--navy);
        }

        .table-responsive {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }
        
        thead {
            background: var(--navy);
            color: #fff;
        }
        
        thead th {
            border-color: rgba(255, 255, 255, 0.1) !important;
            font-weight: 500;
        }
        
        .status-badge {
            padding: .35rem .85rem;
            border-radius: 50px;
            font-size: .8rem;
            font-weight: 500;
            text-transform: capitalize;
        }

        .status-pending { background: #ffc1071a; color: #ffc107; }
        .status-disetujui { background: #28a7451a; color: #28a745; }
        .status-ditolak { background: #dc35451a; color: #dc3545; }
        
        .btn-action {
            width: 38px;
            height: 38px;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            transition: all 0.2s ease;
        }

        .btn-action:hover {
            transform: scale(1.1);
        }
        
        .btn-view { background-color: #17a2b8; color: #fff; }
        .btn-view:hover { background-color: #138496; }
        .btn-edit { background-color: #ffc107; color: #fff; }
        .btn-edit:hover { background-color: #e0a800; }
        .btn-delete { background-color: #dc3545; color: #fff; }
        .btn-delete:hover { background-color: #c82333; }
        
        .btn-custom-secondary {
            background-color: var(--navy);
            border-color: var(--navy);
            color: white;
            font-weight: 600;
            padding: .6rem 1.5rem;
            border-radius: 50px;
        }
        .btn-custom-secondary:hover {
            background-color: #1A4D90;
        }
        .btn-reset {
            color: var(--gray-dark);
            border-color: var(--gray-dark);
            font-weight: 600;
            padding: .6rem 1.5rem;
            border-radius: 50px;
        }
        .btn-reset:hover {
            background-color: var(--gray-dark);
            color: white;
        }

        .form-select {
            border-radius: 50px;
        }

        .pagination .page-link {
            border-radius: 50% !important;
            margin: 0 5px;
            color: var(--navy);
            border: 1px solid #ddd;
            transition: all 0.3s ease;
        }
        
        .pagination .page-item.active .page-link {
            background-color: var(--navy);
            border-color: var(--navy);
            color: white;
        }
        
        .pagination .page-link:hover {
            background-color: var(--accent);
            border-color: var(--accent);
            color: white;
        }

        .search-container {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 2rem;
            align-items: center;
        }

        @media(max-width: 768px) {
            .sidebar {
                left: -260px;
            }
            .sidebar.show {
                left: 0;
            }
            .content {
                margin-left: 0;
            }
            .navbar, .content {
                margin-left: 0;
            }
        }
    </style>
</head>

<body>
    <aside id="sidebar" class="sidebar">
        <div class="sidebar-header">
            <img src="../assets/img/logotng.png" alt="Logo">
            <h5 class="mt-2">Dashboard Admin</h5>
        </div>
        <div class="sidebar-nav">
            <a href="dashboard_admin.php"><i class="fas fa-home"></i> <span>Dashboard</span></a>
            <a href="kelola_reserv.php" class="active"><i class="fas fa-table"></i> <span>Data Reservasi</span></a>
            <a href="kelola_tempat.php"><i class="fas fa-map-marker-alt"></i> <span>Kelola Tempat</span></a>
            <a href="calendar.php"><i class="fas fa-calendar-alt"></i> <span>Kalender</span></a>
            <a href="logout_admin.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>
    </aside>

    <nav class="navbar fixed-top">
        <div class="container-fluid px-4">
            <button id="sidebarToggle" class="btn btn-sm btn-outline-dark d-lg-none" title="Menu"><i class="fas fa-bars"></i></button>
            <span class="navbar-brand d-none d-lg-block fw-semibold">Daftar Reservasi</span>
            <div class="d-flex align-items-center gap-2 ms-auto">
                <button id="fullscreenToggle" class="btn btn-sm btn-outline-dark" title="Fullscreen"><i class="fas fa-expand"></i></button>
            </div>
        </div>
    </nav>


    <main class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <h5 class="fw-semibold mb-3">Filter Reservasi</h5>
                    <form class="search-container" method="GET">
                        <input type="text" name="kode_booking" class="form-control" placeholder="Kode Booking" value="<?= htmlspecialchars($kode_booking_search) ?>">
                        <input type="text" name="nama" class="form-control" placeholder="Nama" value="<?= htmlspecialchars($nama_search) ?>">
                        <input type="text" name="tempat" class="form-control" placeholder="Tempat" value="<?= htmlspecialchars($tempat_search) ?>">
                        <input type="date" name="hari" class="form-control" value="<?= htmlspecialchars($hari_search) ?>">
                        <select name="status" class="form-select form-control">
                            <option value="">Semua Status</option>
                            <option value="pending" <?= $status_search === 'pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="disetujui" <?= $status_search === 'disetujui' ? 'selected' : '' ?>>Disetujui</option>
                            <option value="ditolak" <?= $status_search === 'ditolak' ? 'selected' : '' ?>>Ditolak</option>
                        </select>
                        <button class="btn btn-custom-secondary" type="submit"><i class="fas fa-search me-1"></i>Cari</button>
                        <a href="kelola_reserv.php" class="btn btn-reset"><i class="fas fa-undo me-1"></i>Reset</a>
                    </form>

                    <h5 class="fw-semibold mt-4 mb-3">Daftar Reservasi</h5>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Kode Booking</th>
                                    <th>Nama</th>
                                    <th>Email</th>
                                    <th>Tempat</th>
                                    <th>Hari</th>
                                    <th>Jam Mulai</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result->num_rows > 0): ?>
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <?php $badgeClass = $row['status'] === 'pending' ? 'status-pending' : ($row['status'] === 'disetujui' ? 'status-disetujui' : 'status-ditolak'); ?>
                                        <tr id="row-<?= $row['id'] ?>">
                                            <td><?= htmlspecialchars($row['kode_booking']) ?></td>
                                            <td><?= htmlspecialchars($row['nama']) ?></td>
                                            <td><?= htmlspecialchars($row['surat']) ?></td>
                                            <td><?= htmlspecialchars($row['tempat']) ?></td>
                                            <td><?= htmlspecialchars($row['hari']) ?></td>
                                            <td><?= htmlspecialchars($row['jam_mulai']) ?></td>
                                            <td id="status-<?= $row['id'] ?>"><span class="status-badge <?= $badgeClass ?>"><?= ucfirst($row['status']) ?></span></td>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    <a class="btn btn-action btn-view" href="view_reserv.php?id=<?= $row['id'] ?>"><i class="fas fa-eye"></i></a>
                                                    <a class="btn btn-action btn-edit" href="edit_reserv.php?id=<?= $row['id'] ?>"><i class="fas fa-edit"></i></a>
                                                    <button class="btn btn-action btn-delete delete-reservation" data-id="<?= $row['id'] ?>"><i class="fas fa-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-4 text-muted">Tidak ada data ditemukan</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <nav class="d-flex justify-content-center justify-content-sm-between align-items-center mt-4">
                        <p class="text-muted d-none d-sm-block mb-0">Menampilkan halaman <?= $current_page ?> dari <?= $total_pages ?></p>
                        <ul class="pagination mb-0">
                            <?php if ($current_page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $current_page - 1; ?>">Previous</a>
                                </li>
                            <?php endif; ?>

                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?= $i == $current_page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?= $i; ?>"> <?= $i; ?> </a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($current_page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $current_page + 1; ?>">Next</a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        // --- LOGIC SIDEBAR & FULLSCREEN ---
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const fullscreenToggle = document.getElementById('fullscreenToggle');
        
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                const isMobile = window.matchMedia('(max-width: 768px)').matches;
                if (isMobile) {
                    sidebar.classList.toggle('show');
                } else {
                    document.body.classList.toggle('sidebar-collapsed');
                }
            });
        }
        
        if (fullscreenToggle) {
            fullscreenToggle.addEventListener('click', () => {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-compress"></i>';
                } else {
                    document.exitFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-expand"></i>';
                }
            });
        }
        
        document.addEventListener('click', e => {
            const isMobile = window.matchMedia('(max-width: 768px)').matches;
            if (isMobile && sidebar.classList.contains('show') && !sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        });

        // --- AJAX DELETE RESERVATION ---
        $(document).on('click', '.delete-reservation', function () {
            var id = $(this).data("id");
        
            Swal.fire({
                title: 'Yakin ingin menghapus?',
                text: "Data tidak bisa dikembalikan setelah dihapus!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "delete_reservation.php",
                        method: "POST",
                        data: {
                            id: id
                        },
                        success: function(response) {
                            if (response === 'success') {
                                $("#row-" + id).remove();
                                Swal.fire('Deleted!', 'Reservasi telah dihapus.', 'success');
                            } else {
                                Swal.fire('Error!', 'Gagal menghapus data.', 'error');
                            }
                        }
                    });
                }
            });
        });
    </script>
</body>

</html>