<?php
session_start();
include '../db.php';

// Pastikan admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

// Ambil ID tempat dari URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "ID tempat tidak ditemukan.";
    exit;
}

$place_id = intval($_GET['id']);

// Ambil data tempat utama
$sql_place = "SELECT * FROM places WHERE id = ?";
$stmt_place = $conn->prepare($sql_place);
$stmt_place->bind_param("i", $place_id);
$stmt_place->execute();
$result_place = $stmt_place->get_result();
$place = $result_place->fetch_assoc();
$stmt_place->close();

// Ambil data galeri foto
$sql_images = "SELECT * FROM place_images WHERE place_id = ?";
$stmt_images = $conn->prepare($sql_images);
$stmt_images->bind_param("i", $place_id);
$stmt_images->execute();
$result_images = $stmt_images->get_result();
$images = $result_images->fetch_all(MYSQLI_ASSOC);
$stmt_images->close();

if (!$place) {
    echo "Data tempat tidak ditemukan.";
    exit;
}

// Gabungkan gambar utama ke dalam array galeri untuk carousel
$all_images = array_merge([['image_path' => $place['image']]], $images);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Tempat: <?= htmlspecialchars($place['name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon">
    <style>
        :root {
            --navy: #1C2B36;
            --navy-dark: #151E27;
            --accent: #FFD43B;
            --gray-light: #f4f6fb;
            --gray-dark: #6c757d;
            --sidebar-width: 260px;
            --sidebar-collapsed: 80px;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--gray-light);
            overflow-x: hidden;
            transition: margin-left .3s;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--navy) 0%, var(--navy-dark) 100%);
            color: #fff;
            padding: 20px 0;
            transition: width .3s, left .3s;
            z-index: 1040;
            display: flex;
            flex-direction: column;
        }

        .sidebar.collapsed {
            width: var(--sidebar-collapsed);
        }

        .sidebar-header {
            text-align: center;
            padding: 10px 0 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        .sidebar-header h5 {
            font-weight: 600;
            transition: opacity 0.3s;
        }

        .sidebar.collapsed .sidebar-header h5 {
            opacity: 0;
        }

        .sidebar-header img {
            max-height: 40px;
        }

        .sidebar-nav a {
            color: #fff;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 22px;
            text-decoration: none !important;
            border-radius: 6px;
            margin: 4px 10px;
            font-weight: 500;
            white-space: nowrap;
            transition: background .2s, transform .2s;
        }

        .sidebar-nav a i {
            min-width: 22px;
            text-align: center;
            font-size: 1rem;
        }

        .sidebar.collapsed .sidebar-nav a span {
            display: none;
        }

        .sidebar-nav a.active,
        .sidebar-nav a:hover {
            background-color: rgba(255, 212, 59, 0.1);
            color: var(--accent);
            transform: translateX(5px);
        }

        .sidebar-nav a.active {
            border-left: 3px solid var(--accent);
            padding-left: 19px;
        }

        /* Navbar */
        .navbar {
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            height: 60px;
            transition: margin-left .3s;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1030;
        }

        .navbar-brand {
            color: var(--navy) !important;
            font-weight: 600;
            font-size: 1.25rem;
        }

        .btn-outline-dark {
            border-color: #ddd !important;
            color: #333 !important;
        }

        /* Content */
        .content {
            margin-left: var(--sidebar-width);
            padding: 80px 2.5rem 4rem;
            transition: margin-left .3s;
        }

        body.sidebar-collapsed .navbar {
            margin-left: var(--sidebar-collapsed);
        }

        body.sidebar-collapsed .content {
            margin-left: var(--sidebar-collapsed);
        }

        /* Detail Card */
        .card-detail {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .05);
            padding: 2.5rem;
            margin-bottom: 2rem;
        }

        .card-header {
            background: transparent;
            border-bottom: none;
            padding: 0 0 1.5rem 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-header h5 {
            font-weight: 600;
            color: var(--navy);
        }

        /* Main Image & Gallery */
        .main-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .thumbnail-gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }

        .thumbnail-gallery img {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 6px;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.2s ease;
        }

        .thumbnail-gallery img.active,
        .thumbnail-gallery img:hover {
            border-color: var(--accent);
            transform: scale(1.05);
        }

        /* Detail List */
        .detail-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .detail-list li {
            margin-bottom: 1rem;
        }

        .detail-list i {
            width: 25px;
            text-align: center;
            color: var(--navy);
            margin-right: 10px;
        }

        .btn-action {
            padding: 10px 25px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-edit { background-color: #28a745; border-color: #28a745; color: #fff; }
        .btn-edit:hover { background-color: #218838; }
        .btn-back { background-color: var(--gray-dark); border-color: var(--gray-dark); color: #fff; }
        .btn-back:hover { background-color: #5a6268; }

        /* Modal */
        .modal-content {
            border-radius: 12px;
            background-color: #fff;
        }
        
        .modal-header {
            border-bottom: none;
        }
        
        .modal-title {
            font-weight: 600;
            color: var(--navy);
        }
        
        .modal-body img {
            border-radius: 10px;
        }

        /* Responsive Modal width */
        @media (min-width: 768px) {
            .modal-md-dialog {
                max-width: 650px;
            }
        }
        
        @media(max-width:768px) {
            .sidebar {
                left: -260px;
            }
            .sidebar.show {
                left: 0;
            }
            .content {
                margin-left: 0;
            }
            .navbar,
            .content {
                margin-left: 0;
            }
        }
    </style>
</head>

<body>
    <aside id="sidebar" class="sidebar">
        <div class="sidebar-header">
            <img src="../assets/img/logotng.png" alt="Logo">
            <h5 class="mt-2">Dashboard Admin</h5>
        </div>
        <div class="sidebar-nav">
            <a href="dashboard_admin.php"><i class="fas fa-home"></i> <span>Dashboard</span></a>
            <a href="kelola_reserv.php"><i class="fas fa-table"></i> <span>Data Reservasi</span></a>
            <a class="active" href="kelola_tempat.php"><i class="fas fa-map-marker-alt"></i> <span>Kelola Tempat</span></a>
            <a href="calendar.php"><i class="fas fa-calendar-alt"></i> <span>Kalender</span></a>
            <a href="logout_admin.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>
    </aside>

    <nav class="navbar fixed-top">
        <div class="container-fluid px-4">
            <button id="sidebarToggle" class="btn btn-sm btn-outline-dark d-lg-none" title="Menu"><i class="fas fa-bars"></i></button>
            <span class="navbar-brand d-none d-lg-block fw-semibold">Detail Tempat</span>
            <div class="d-flex align-items-center gap-2 ms-auto">
                <button id="fullscreenToggle" class="btn btn-sm btn-outline-dark" title="Fullscreen"><i class="fas fa-expand"></i></button>
            </div>
        </div>
    </nav>

    <main class="content">
        <div class="container-fluid">
            <div class="card-detail">
                <div class="card-header">
                    <h5>Detail Tempat</h5>
                </div>

                <div class="row g-4 mt-3">
                    <div class="col-lg-7">
                        <img id="mainImage" src="../<?= htmlspecialchars($place['image']); ?>" class="main-image" alt="<?= htmlspecialchars($place['name']); ?>">

                        <div class="thumbnail-gallery">
                            <?php foreach ($all_images as $key => $img): ?>
                                <img src="../<?= htmlspecialchars($img['image_path']); ?>" onclick="openModal(<?= $key ?>)" alt="Thumbnail Galeri" data-bs-toggle="modal" data-bs-target="#galleryModal">
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="col-lg-5">
                        <h2 class="fw-bold text-primary-custom mb-4"><?= htmlspecialchars($place['name']); ?></h2>
                        <ul class="detail-list">
                            <li>
                                <i class="fas fa-info-circle"></i>
                                <strong>Deskripsi</strong><br>
                                <span><?= nl2br(htmlspecialchars($place['description'])); ?></span>
                            </li>
                            <li>
                                <i class="fas fa-map-marked-alt"></i>
                                <strong>Lokasi</strong><br>
                                <span>
                                    <a href="<?= htmlspecialchars($place['lokasi']); ?>" target="_blank" class="text-decoration-none text-primary-custom">
                                        Lihat di Google Maps
                                    </a>
                                </span>
                            </li>
                        </ul>
                        <div class="d-flex gap-2 mt-4">
                            <a href="edit_tempat.php?id=<?= $place['id'] ?>" class="btn btn-edit btn-action"><i class="fas fa-edit me-2"></i>Edit Tempat</a>
                            <a href="kelola_tempat.php" class="btn btn-back btn-action"><i class="fas fa-arrow-left me-2"></i>Kembali</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <div class="modal fade" id="galleryModal" tabindex="-1" aria-labelledby="galleryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="galleryModalLabel">Galeri Foto</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="imageCarousel" class="carousel slide" data-bs-ride="false">
                        <div class="carousel-inner">
                            <?php foreach ($all_images as $key => $img): ?>
                                <div class="carousel-item <?= $key === 0 ? 'active' : '' ?>">
                                    <img src="../<?= htmlspecialchars($img['image_path']); ?>" class="d-block w-100" alt="Gallery Image">
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#imageCarousel" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#imageCarousel" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const fullscreenToggle = document.getElementById('fullscreenToggle');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                const isMobile = window.matchMedia('(max-width: 768px)').matches;
                if (isMobile) {
                    sidebar.classList.toggle('show');
                } else {
                    document.body.classList.toggle('sidebar-collapsed');
                }
            });
        }
        
        if (fullscreenToggle) {
            fullscreenToggle.addEventListener('click', () => {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-compress"></i>';
                } else {
                    document.exitFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-expand"></i>';
                }
            });
        }

        document.addEventListener('click', e => {
            const isMobile = window.matchMedia('(max-width: 768px)').matches;
            if (isMobile && sidebar.classList.contains('show') && !sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        });
        
        function changeMainImage(thumbnail) {
            const mainImage = document.getElementById('mainImage');
            mainImage.src = thumbnail.src;
            
            const thumbnails = document.querySelectorAll('.thumbnail-gallery img');
            thumbnails.forEach(img => img.classList.remove('active'));
            thumbnail.classList.add('active');
        }
        
        function openModal(index) {
             const carousel = new bootstrap.Carousel(document.getElementById('imageCarousel'), { interval: false });
             carousel.to(index);
        }

        document.addEventListener('DOMContentLoaded', () => {
            const thumbnailImages = document.querySelectorAll('.thumbnail-gallery img');
            
            thumbnailImages.forEach((thumbnail, index) => {
                thumbnail.addEventListener('click', () => {
                    openModal(index);
                });
            });
        });
    </script>
</body>
</html>