<?php
session_start();
include '../db.php';

// Pastikan admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

// Pastikan ID reservasi tersedia
if (!isset($_GET['id'])) {
    echo "ID reservasi tidak ditemukan.";
    exit;
}
$id = intval($_GET['id']); // Sanitasi ID

// Ambil detail reservasi berdasarkan ID
$query = "SELECT * FROM reservations WHERE id = $id";
$result = $conn->query($query);

if (!$result || $result->num_rows === 0) {
    echo "Reservasi tidak ditemukan.";
    exit;
}
$reservation = $result->fetch_assoc();

// Ambil daftar tempat
$queryPlaces = "SELECT name FROM places"; // Tabel tempat
$resultPlaces = $conn->query($queryPlaces);

if (!$resultPlaces) {
    echo "Error: " . $conn->error;
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi data input
    $nama = $conn->real_escape_string($_POST['nama']);
    $no_telepon = $conn->real_escape_string($_POST['no_telepon']);
    $surat = $conn->real_escape_string($_POST['email']);
    $tempat = $conn->real_escape_string($_POST['tempat']);
    $keterangan = $conn->real_escape_string($_POST['keterangan']);
    $catatan = $conn->real_escape_string($_POST['catatan']);
    $status = $conn->real_escape_string($_POST['status']); // Ambil nilai status dari form

    // Perbarui data reservasi
    $sql = "UPDATE reservations SET 
                nama='$nama', 
                no_telepon='$no_telepon', 
                surat='$surat', 
                tempat='$tempat', 
                keterangan='$keterangan', 
                catatan='$catatan',
                status='$status' 
            WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        header('Location: kelola_reserv.php');
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Reservasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: #002D62;
            --secondary-color: #F0F2F5;
            --accent-color: #FF5733;
            --card-bg: #FFFFFF;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--secondary-color);
            color: #333;
            padding: 2rem;
        }

        .container {
            max-width: 900px;
        }

        .card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            padding: 3rem;
            background-color: var(--card-bg);
        }

        h1 {
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 2rem;
            text-align: center;
        }

        .form-label {
            font-weight: 500;
            color: var(--primary-color);
        }

        .form-control, .form-select {
            border-radius: 12px;
            border: 1px solid #ddd;
            padding: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(255, 87, 51, 0.25);
        }

        .btn-action {
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary-custom {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }

        .btn-primary-custom:hover {
            background-color: #1A4D90;
            border-color: #1A4D90;
        }
        
        .btn-secondary-custom {
            background-color: #6C757D;
            border-color: #6C757D;
            color: white;
        }
        
        .btn-secondary-custom:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container my-5">
        <div class="card">
            <h1>Edit Reservasi</h1>
            <form method="post" id="editForm">
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nama" class="form-label">Nama:</label>
                            <input type="text" class="form-control" id="nama" name="nama" value="<?= htmlspecialchars($reservation['nama']); ?>" required>
                        </div>
                        <div class="form-group mt-3">
                            <label for="no_telepon" class="form-label">No Telepon:</label>
                            <input type="text" class="form-control" id="no_telepon" name="no_telepon" value="<?= htmlspecialchars($reservation['no_telepon']); ?>" required>
                        </div>
                        <div class="form-group mt-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?= htmlspecialchars($reservation['surat']); ?>" required>
                        </div>
                        <div class="form-group mt-3">
                            <label for="tempat" class="form-label">Tempat:</label>
                            <select name="tempat" id="tempat" class="form-select" required>
                                <option value="">-</option>
                                <?php while ($places = $resultPlaces->fetch_assoc()): ?>
                                    <option value="<?= htmlspecialchars($places['name']); ?>" <?= $reservation['tempat'] === $places['name'] ? 'selected' : ''; ?>>
                                        <?= htmlspecialchars($places['name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="keterangan" class="form-label">Keterangan:</label>
                            <textarea class="form-control" id="keterangan" name="keterangan" rows="5" required><?= htmlspecialchars($reservation['keterangan']); ?></textarea>
                        </div>
                        <div class="form-group mt-3">
                            <label for="catatan" class="form-label">Catatan:</label>
                            <textarea class="form-control" id="catatan" name="catatan" rows="5" required><?= htmlspecialchars($reservation['catatan']); ?></textarea>
                        </div>
                        <div class="form-group mt-3">
                            <label for="status" class="form-label">Status Reservasi:</label>
                            <select name="status" id="status" class="form-select" required>
                                <option value="pending" <?= $reservation['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="disetujui" <?= $reservation['status'] === 'disetujui' ? 'selected' : ''; ?>>Disetujui</option>
                                <option value="ditolak" <?= $reservation['status'] === 'ditolak' ? 'selected' : ''; ?>>Ditolak</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-end gap-3 mt-4">
                    <button type="button" class="btn btn-primary-custom btn-action" onclick="confirmSave()"><i class="fas fa-save me-2"></i>Simpan Perubahan</button>
                    <a href="kelola_reserv.php" class="btn btn-secondary-custom btn-action"><i class="fas fa-times me-2"></i>Batal</a>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function confirmSave() {
            Swal.fire({
                title: 'Apakah sudah benar?',
                text: "Data yang Anda masukkan akan diperbarui!",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, simpan!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('editForm').submit();
                }
            });
        }
    </script>
</body>

</html>