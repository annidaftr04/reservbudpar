<?php
include '../db.php';
session_start();

// Pastikan admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

// Proses Hapus Data Tempat
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id = intval($_POST['id']);

    // Ambil data gambar tempat sebelum dihapus
    $sql = "SELECT image FROM places WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $place = $result->fetch_assoc();

    // Hapus gambar terkait jika ada
    if ($place && $place['image']) {
        $imagePath = "../" . $place['image'];
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }

    // Hapus data tempat dari database
    $sql = "DELETE FROM places WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        header('Location: kelola_tempat.php');
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }
}

// Pagination setup
$items_per_page = 8;
$current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($current_page - 1) * $items_per_page;

// Ambil data tempat dengan limit dan offset
$sql = "SELECT * FROM places LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $items_per_page, $offset);
$stmt->execute();
$places = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Hitung total data untuk pagination
$sql_count = "SELECT COUNT(*) AS total FROM places";
$total_data = $conn->query($sql_count)->fetch_assoc()['total'];
$total_pages = ceil($total_data / $items_per_page);

function h($string)
{
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kelola Tempat</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon" />
    <style>
        :root {
            --navy: #1C2B36;
            --navy-dark: #151E27;
            --accent: #FFD43B;
            --gray-light: #f4f6fb;
            --gray-dark: #6c757d;
            --sidebar-width: 260px;
            --sidebar-collapsed: 80px;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--gray-light);
            overflow-x: hidden;
            transition: margin-left .3s;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--navy) 0%, var(--navy-dark) 100%);
            color: #fff;
            padding: 20px 0;
            transition: width .3s, left .3s;
            z-index: 1040;
            display: flex;
            flex-direction: column;
        }

        .sidebar.collapsed {
            width: var(--sidebar-collapsed);
        }

        .sidebar-header {
            text-align: center;
            padding: 10px 0 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        .sidebar-header h5 {
            font-weight: 600;
            transition: opacity 0.3s;
        }

        .sidebar.collapsed .sidebar-header h5 {
            opacity: 0;
        }
        
        .sidebar-header img {
            max-height: 40px;
        }

        .sidebar-nav a {
            color: #fff;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 22px;
            text-decoration: none !important;
            border-radius: 6px;
            margin: 4px 10px;
            font-weight: 500;
            white-space: nowrap;
            transition: background .2s, transform .2s;
        }

        .sidebar-nav a i {
            min-width: 22px;
            text-align: center;
            font-size: 1rem;
        }

        .sidebar.collapsed .sidebar-nav a span {
            display: none;
        }

        .sidebar-nav a.active,
        .sidebar-nav a:hover {
            background-color: rgba(255, 212, 59, 0.1);
            color: var(--accent);
            transform: translateX(5px);
        }

        .sidebar-nav a.active {
            border-left: 3px solid var(--accent);
            padding-left: 19px;
        }

        /* Navbar */
        .navbar {
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            height: 60px;
            transition: margin-left .3s;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1030;
        }
        
        .navbar-brand {
            color: var(--navy) !important;
            font-weight: 600;
            font-size: 1.25rem;
        }

        /* Content */
        .content {
            margin-left: var(--sidebar-width);
            padding: 80px 2.5rem 4rem;
            transition: margin-left .3s;
        }

        body.sidebar-collapsed .navbar {
            margin-left: var(--sidebar-collapsed);
        }

        body.sidebar-collapsed .content {
            margin-left: var(--sidebar-collapsed);
        }

        /* Card & Table */
        .card-body {
            padding: 2.5rem;
        }

        .card-header {
            background: transparent;
            border-bottom: none;
            padding: 0 0 1.5rem 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h5 {
            font-weight: 600;
            color: var(--navy);
        }

        .table-responsive {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }

        thead {
            background: var(--navy);
            color: #fff;
        }
        
        thead th {
            border-color: rgba(255, 255, 255, 0.1) !important;
            font-weight: 500;
        }

        .img-thumb {
            width: 90px;
            height: 60px;
            object-fit: cover;
            border-radius: 6px;
            box-shadow: 0 0 5px rgba(0, 0, 0, .1);
        }

        .btn-action {
            width: 38px;
            height: 38px;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            transition: all 0.2s ease;
        }

        .btn-action:hover {
            transform: scale(1.1);
        }

        .btn-edit { background-color: #28a745; border-color: #28a745; color: #fff; }
        .btn-edit:hover { background-color: #218838; }
        .btn-delete { background-color: #dc3545; border-color: #dc3545; color: #fff; }
        .btn-delete:hover { background-color: #c82333; }
        .btn-view { background-color: #17a2b8; border-color: #17a2b8; color: #fff; }
        .btn-view:hover { background-color: #138496; }
        
        .btn-tambah {
            background-color: var(--accent);
            border: none;
            color: var(--navy-dark);
            font-weight: 600;
            padding: .6rem 1.5rem;
            border-radius: 50px;
            transition: transform .2s ease;
        }
        
        .btn-tambah:hover {
            background-color: #FFC700;
            transform: translateY(-2px);
        }
        
        .pagination .page-link {
            border-radius: 50% !important;
            margin: 0 5px;
            color: var(--navy);
            border: 1px solid #ddd;
            transition: all 0.3s ease;
        }
        
        .pagination .page-item.active .page-link {
            background-color: var(--navy);
            border-color: var(--navy);
            color: white;
        }
        
        .pagination .page-link:hover {
            background-color: var(--accent);
            border-color: var(--accent);
            color: white;
        }

        @media (max-width: 768px) {
            .sidebar {
                left: -260px;
            }
            .sidebar.show {
                left: 0;
            }
            .content {
                margin-left: 0;
            }
            .navbar, .content {
                margin-left: 0;
            }
        }
    </style>
</head>

<body>
    <aside id="sidebar" class="sidebar">
        <div class="sidebar-header">
            <img src="../assets/img/logotng.png" alt="Logo">
            <h5 class="mt-2">Dashboard Admin</h5>
        </div>
        <div class="sidebar-nav">
            <a href="dashboard_admin.php"><i class="fas fa-home"></i> <span>Dashboard</span></a>
            <a href="kelola_reserv.php"><i class="fas fa-table"></i> <span>Data Reservasi</span></a>
            <a href="kelola_tempat.php" class="active"><i class="fas fa-map-marker-alt"></i> <span>Kelola Tempat</span></a>
            <a href="calendar.php"><i class="fas fa-calendar-alt"></i> <span>Kalender</span></a>
            <a href="logout_admin.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>
    </aside>

    <nav class="navbar fixed-top">
        <div class="container-fluid px-4">
            <button id="sidebarToggle" class="btn btn-sm btn-outline-dark d-lg-none" title="Menu"><i class="fas fa-bars"></i></button>
            <span class="navbar-brand d-none d-lg-block fw-semibold">Kelola Tempat</span>
            <div class="d-flex align-items-center gap-2 ms-auto">
                <button id="fullscreenToggle" class="btn btn-sm btn-outline-dark" title="Fullscreen"><i class="fas fa-expand"></i></button>
            </div>
        </div>
    </nav>

    <main class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <div class="card-header">
                        <h5>Daftar Tempat</h5>
                        <a href="tambah_tempat.php" class="btn btn-tambah d-inline-flex align-items-center">
                            <i class="fas fa-plus me-2"></i>Tambah Tempat
                        </a>
                    </div>

                    <div class="table-responsive mt-4">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Nama Tempat</th>
                                    <th>Deskripsi</th>
                                    <th>Lokasi</th>
                                    <th>Gambar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($places)): foreach ($places as $p): ?>
                                    <tr>
                                        <td><?= h($p['name']) ?></td>
                                        <td style="max-width:300px;white-space:pre-wrap;"><?= h($p['description']) ?></td>
                                        <td><?= h($p['lokasi']) ?></td>
                                        <td><img src="../<?= h($p['image']) ?>" alt="<?= h($p['name']) ?>" class="img-thumb"></td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="detail_tempat.php?id=<?= $p['id'] ?>" class="btn btn-action btn-view"><i class="fas fa-eye"></i></a>
                                                <a href="edit_tempat.php?id=<?= $p['id'] ?>" class="btn btn-action btn-edit"><i class="fas fa-edit"></i></a>
                                                <form method="POST" style="display:inline;" id="deleteForm_<?= $p['id'] ?>">
                                                    <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <button type="button" class="btn btn-action btn-delete" onclick="confirmDelete(<?= $p['id'] ?>)"><i class="fas fa-trash"></i></button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4 text-muted">Belum ada tempat yang terdaftar.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <nav class="d-flex justify-content-center justify-content-sm-between align-items-center mt-4">
                        <p class="text-muted d-none d-sm-block mb-0">Halaman <?= $current_page ?> dari <?= $total_pages ?></p>
                        <ul class="pagination mb-0">
                            <?php if ($current_page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $current_page - 1; ?>"><i class="fas fa-chevron-left"></i></a>
                                </li>
                            <?php endif; ?>

                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?= $i == $current_page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?= $i; ?>"> <?= $i; ?> </a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($current_page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $current_page + 1; ?>"><i class="fas fa-chevron-right"></i></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Anda yakin?',
                text: "Data ini akan dihapus secara permanen!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('deleteForm_' + id).submit();
                }
            });
        }

        const sidebar = document.getElementById('sidebar');
        const content = document.querySelector('.content');
        const navbar = document.querySelector('.navbar');
        const sidebarToggle = document.getElementById('sidebarToggle');

        // Toggle sidebar
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                const isMobile = window.matchMedia('(max-width: 768px)').matches;
                if (isMobile) {
                    sidebar.classList.toggle('show');
                } else {
                    document.body.classList.toggle('sidebar-collapsed');
                }
            });
        }

        // Handle fullscreen
        const fullscreenToggle = document.getElementById('fullscreenToggle');
        if (fullscreenToggle) {
            fullscreenToggle.addEventListener('click', () => {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-compress"></i>';
                } else {
                    document.exitFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-expand"></i>';
                }
            });
        }

        // Close mobile sidebar on outside click
        document.addEventListener('click', e => {
            const isMobile = window.matchMedia('(max-width: 768px)').matches;
            if (isMobile && sidebar.classList.contains('show') && !sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        });
    </script>
</body>
</html>