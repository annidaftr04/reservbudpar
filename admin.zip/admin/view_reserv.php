<?php
session_start();
include '../db.php';

// Cek apakah admin sudah login dan memiliki role 'admin'
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

// Ambil ID reservasi dari URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "ID reservasi tidak ditemukan.";
    exit;
}

$id = intval($_GET['id']);

// Cek apakah ID adalah angka yang valid
if ($id <= 0) {
    echo "ID reservasi tidak valid.";
    exit;
}

// Ambil detail reservasi berdasarkan ID
$query = "SELECT * FROM reservations WHERE id = $id";
$result = $conn->query($query);

if ($result->num_rows == 0) {
    echo "Reservasi tidak ditemukan.";
    exit;
}

$reservation = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Reservasi</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0f2f5;
        }
        .container {
            max-width: 900px;
        }
        .card-detail {
            border: none;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        .card-header-custom {
            background-color: #002D62;
            color: #fff;
            padding: 1.5rem;
            border-top-left-radius: 1rem;
            border-top-right-radius: 1rem;
        }
        .detail-item {
            display: flex;
            align-items: center;
            margin-bottom: 1.25rem;
        }
        .detail-item i {
            width: 30px;
            text-align: center;
            margin-right: 15px;
            color: #002D62;
        }
        .detail-item strong {
            color: #333;
            font-weight: 600;
        }
        .detail-item span {
            color: #666;
            margin-left: 5px;
        }
        .status-badge {
            font-size: 1rem;
            padding: 0.5em 1em;
            border-radius: 20px;
        }
        .btn-back-custom {
            background-color: #6c757d;
            border-color: #6c757d;
            color: #fff;
            border-radius: 25px;
            padding: 10px 25px;
            transition: all 0.3s ease;
        }
        .btn-back-custom:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="card card-detail">
            <div class="card-header-custom text-center">
                <h3 class="mb-0 fw-bold">Detail Reservasi</h3>
                <p class="mb-0 mt-2">Kode Booking: <?= htmlspecialchars($reservation['kode_booking']); ?></p>
            </div>
            <div class="card-body p-5">
                <div class="row">
                    <div class="col-md-6">
                        <div class="detail-item">
                            <i class="fas fa-user-circle"></i>
                            <div>
                                <strong>Nama:</strong>
                                <span><?= htmlspecialchars($reservation['nama']); ?></span>
                            </div>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-phone-alt"></i>
                            <div>
                                <strong>No Telepon:</strong>
                                <span><?= htmlspecialchars($reservation['no_telepon']); ?></span>
                            </div>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-envelope"></i>
                            <div>
                                <strong>Email:</strong>
                                <span><?= htmlspecialchars($reservation['surat']); ?></span>
                            </div>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <div>
                                <strong>Tempat:</strong>
                                <span><?= htmlspecialchars($reservation['tempat']); ?></span>
                            </div>
                        </div>
                        <?php if ($reservation['sub_tempat']): ?>
                            <div class="detail-item">
                                <i class="fas fa-door-open"></i>
                                <div>
                                    <strong>Bagian:</strong>
                                    <span><?= htmlspecialchars($reservation['sub_tempat']); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <div class="detail-item">
                            <i class="fas fa-calendar-alt"></i>
                            <div>
                                <strong>Tanggal:</strong>
                                <span><?= htmlspecialchars($reservation['hari']); ?></span>
                            </div>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-clock"></i>
                            <div>
                                <strong>Waktu:</strong>
                                <span><?= htmlspecialchars($reservation['jam_mulai'] . ' - ' . $reservation['jam_selesai']); ?></span>
                            </div>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-info-circle"></i>
                            <div>
                                <strong>Keterangan:</strong>
                                <span><?= htmlspecialchars($reservation['keterangan']); ?></span>
                            </div>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-file-upload"></i>
                            <div>
                                <strong>File Proposal:</strong>
                                <?php if ($reservation['file_upload']): ?>
                                    <span><a href="../uploads/<?= htmlspecialchars($reservation['file_upload']); ?>" target="_blank" class="text-decoration-none">Lihat File</a></span>
                                <?php else: ?>
                                    <span>Tidak ada</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-id-card"></i>
                            <div>
                                <strong>File KTP:</strong>
                                <?php if ($reservation['ktp_upload']): ?>
                                    <span><a href="../uploads/ktp/<?= htmlspecialchars($reservation['ktp_upload']); ?>" target="_blank" class="text-decoration-none">Lihat KTP</a></span>
                                <?php else: ?>
                                    <span>Tidak ada</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <hr class="my-4">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
                    <div>
                        <strong class="d-block mb-2">Status Reservasi:</strong>
                        <?php
                        $status_class = '';
                        switch ($reservation['status']) {
                            case 'disetujui':
                                $status_class = 'bg-success';
                                break;
                            case 'pending':
                                $status_class = 'bg-warning text-dark';
                                break;
                            case 'ditolak':
                                $status_class = 'bg-danger';
                                break;
                            default:
                                $status_class = 'bg-secondary';
                                break;
                        }
                        ?>
                        <span class="badge <?= $status_class; ?> status-badge"><?= htmlspecialchars($reservation['status']); ?></span>
                    </div>
                    <div>
                        <strong class="d-block mt-3 mt-md-0 mb-2">Catatan Admin:</strong>
                        <span><?= htmlspecialchars($reservation['catatan'] ?: 'Tidak ada catatan.'); ?></span>
                    </div>
                </div>
            </div>
            <div class="card-footer bg-light text-end p-4">
                <a href="kelola_reserv.php" class="btn btn-back-custom">
                    <i class="fas fa-arrow-left me-2"></i>Kembali
                </a>
            </div>
        </div>
    </div>
</body>

</html>