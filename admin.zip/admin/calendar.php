<?php
session_start();
include '../db.php';
if (!isset($_SESSION['admin_id'])) {
    header('Location: login_admin.php');
    exit;
}

// Ambil data reservasi yang disetujui dari database
$sql = "SELECT nama, tempat, hari, jam_mulai, jam_selesai FROM reservations WHERE status = 'disetujui'";
$result = $conn->query($sql);

$events = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $events[] = [
            'title' => htmlspecialchars($row['tempat']),
            'start' => $row['hari'],
            'extendedProps' => [
                'nama' => htmlspecialchars($row['nama']),
                'tempat' => htmlspecialchars($row['tempat']),
                'jam_mulai' => $row['jam_mulai'],
                'jam_selesai' => $row['jam_selesai'],
            ]
        ];
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kalender Reservasi</title>
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta http-equiv="pragma" content="no-cache">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/main.min.css" rel="stylesheet" />
    <link rel="icon" href="../assets/img/logotng.png" type="image/x-icon" />
    <style>
        :root {
            --navy: #1C2B36;
            --navy-dark: #151E27;
            --accent: #FFD43B;
            --gray-light: #f4f6fb;
            --gray-dark: #6c757d;
            --sidebar-width: 260px;
            --sidebar-collapsed: 80px;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: var(--gray-light);
            overflow-x: hidden;
            transition: margin-left .3s;
        }
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--navy) 0%, var(--navy-dark) 100%);
            color: #fff;
            padding: 20px 0;
            transition: width .3s, left .3s;
            z-index: 1040;
            display: flex;
            flex-direction: column;
        }
        .sidebar.collapsed {
            width: var(--sidebar-collapsed);
        }
        .sidebar-header {
            text-align: center;
            padding: 10px 0 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        .sidebar-header h5 {
            font-weight: 600;
            transition: opacity 0.3s;
        }
        .sidebar.collapsed .sidebar-header h5 {
            opacity: 0;
        }
        .sidebar-header img {
            max-height: 40px;
        }
        .sidebar-nav a {
            color: #fff;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 22px;
            text-decoration: none !important;
            border-radius: 6px;
            margin: 4px 10px;
            font-weight: 500;
            white-space: nowrap;
            transition: background .2s, transform .2s;
        }
        .sidebar-nav a i {
            min-width: 22px;
            text-align: center;
            font-size: 1rem;
        }
        .sidebar.collapsed .sidebar-nav a span {
            display: none;
        }
        .sidebar-nav a.active,
        .sidebar-nav a:hover {
            background-color: rgba(255, 212, 59, 0.1);
            color: var(--accent);
            transform: translateX(5px);
        }
        .sidebar-nav a.active {
            border-left: 3px solid var(--accent);
            padding-left: 19px;
        }
        /* Navbar */
        .navbar {
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            height: 60px;
            transition: margin-left .3s;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1030;
        }
        .navbar-brand {
            color: var(--navy) !important;
            font-weight: 600;
            font-size: 1.25rem;
        }
        .btn-outline-dark {
            border-color: #ddd !important;
            color: #333 !important;
        }
        /* Content */
        .content {
            margin-left: var(--sidebar-width);
            padding: 80px 2.5rem 4rem;
            transition: margin-left .3s;
        }
        body.sidebar-collapsed .navbar {
            margin-left: var(--sidebar-collapsed);
        }
        body.sidebar-collapsed .content {
            margin-left: var(--sidebar-collapsed);
        }
        /* FullCalendar overrides */
        #calendar-container {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .05);
            padding: 2.5rem;
        }
        .fc .fc-toolbar-title {
            font-weight: 600;
            font-size: 1.5rem;
            color: var(--navy);
        }
        .fc .fc-button-primary {
            background-color: var(--navy);
            border-color: var(--navy);
            transition: all 0.3s ease;
        }
        .fc .fc-button {
            padding: 0.35rem 0.75rem;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        .fc .fc-button-primary:not(:disabled):hover {
            background-color: #1C3A5A;
            border-color: #1C3A5A;
        }
        .fc-toolbar.fc-header-toolbar {
            flex-wrap: wrap;
            align-items: center;
        }
        /* Style untuk dropdown baru */
        .fc-toolbar-custom-filter {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: auto; /* Posisikan ke kanan */
            margin-right: 1rem;
        }
        .fc-toolbar-custom-filter .form-select {
            max-width: 120px;
            font-size: 0.9rem;
        }
        .fc-daygrid-event {
            background: var(--accent) !important;
            border: none !important;
            color: var(--navy) !important;
            font-weight: 500;
            border-radius: 4px;
        }
        .fc-daygrid-event:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <aside id="sidebar" class="sidebar">
        <div class="sidebar-header">
            <img src="../assets/img/logotng.png" alt="Logo">
            <h5 class="mt-2">Dashboard Admin</h5>
        </div>
        <div class="sidebar-nav">
            <a href="dashboard_admin.php"><i class="fas fa-home"></i> <span>Dashboard</span></a>
            <a href="kelola_reserv.php"><i class="fas fa-table"></i> <span>Data Reservasi</span></a>
            <a href="kelola_tempat.php"><i class="fas fa-map-marker-alt"></i> <span>Kelola Tempat</span></a>
            <a class="active" href="calendar.php"><i class="fas fa-calendar-alt"></i> <span>Kalender</span></a>
            <a href="logout_admin.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>
    </aside>

    <nav class="navbar">
        <div class="container-fluid px-4">
            <button id="sidebarToggle" class="btn btn-sm btn-outline-dark d-lg-none" title="Menu"><i class="fas fa-bars"></i></button>
            <span class="navbar-brand d-none d-lg-block fw-semibold">Kalender Reservasi</span>
            <div class="d-flex align-items-center gap-2 ms-auto">
                <button id="fullscreenToggle" class="btn btn-sm btn-outline-dark" title="Fullscreen"><i class="fas fa-expand"></i></button>
            </div>
        </div>
    </nav>

    <main class="content">
        <div id="calendar-container">
            <div id="calendar"></div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/main.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Sidebar & Fullscreen logic
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const fullscreenToggle = document.getElementById('fullscreenToggle');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                const isMobile = window.matchMedia('(max-width: 768px)').matches;
                if (isMobile) {
                    sidebar.classList.toggle('show');
                } else {
                    document.body.classList.toggle('sidebar-collapsed');
                }
            });
        }

        if (fullscreenToggle) {
            fullscreenToggle.addEventListener('click', () => {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-compress"></i>';
                } else {
                    document.exitFullscreen();
                    fullscreenToggle.innerHTML = '<i class="fas fa-expand"></i>';
                }
            });
        }

        document.addEventListener('click', e => {
            const isMobile = window.matchMedia('(max-width: 768px)').matches;
            if (isMobile && sidebar.classList.contains('show') && !sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const calendarEl = document.getElementById('calendar');
            const allEvents = <?= json_encode($events); ?>;

            function updateHeader(calendar, currentYear, currentMonth) {
                const monthNames = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
                const titleEl = document.querySelector('.fc-toolbar-title');
                if (titleEl) {
                    titleEl.textContent = `${monthNames[currentMonth]} ${currentYear}`;
                }
            }

            const calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                height: 'auto',
                headerToolbar: {
                    left: '', // Hapus tombol navigasi
                    center: 'title',
                    right: '' // Hapus tombol navigasi
                },
                locale: 'id',
                buttonText: {
                    today: 'Hari Ini',
                    month: 'Bulan',
                },
                events: allEvents,
                eventClick(info) {
                    const tempat = info.event.extendedProps?.tempat || info.event.title;
                    const tanggal = info.event.start.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
                    const jamMulai = info.event.extendedProps?.jam_mulai || '';
                    const jamSelesai = info.event.extendedProps?.jam_selesai || '';
                    const nama = info.event.extendedProps?.nama || '';

                    Swal.fire({
                        title: 'Detail Reservasi',
                        html: `
                            <p class="text-start mb-1"><b>Nama:</b> ${nama}</p>
                            <p class="text-start mb-1"><b>Tempat:</b> ${tempat}</p>
                            <p class="text-start mb-1"><b>Tanggal:</b> ${tanggal}</p>
                            <p class="text-start mb-0"><b>Waktu:</b> ${jamMulai} - ${jamSelesai}</p>
                        `,
                        icon: 'info',
                        customClass: {
                            popup: 'swal2-responsive'
                        }
                    });
                },
                eventDisplay: 'block',
                dayMaxEvents: true,
                datesSet: function(info) {
                    // Perbarui judul toolbar saat tanggal berubah
                    updateHeader(calendar, info.view.calendar.getDate().getFullYear(), info.view.calendar.getDate().getMonth());
                }
            });
            calendar.render();

            // Logika untuk filter kalender berdasarkan fasilitas, bulan, dan tahun
            const toolbar = document.querySelector('.fc-toolbar.fc-header-toolbar');
            
            // Buat container untuk dropdown filter
            const filterContainer = document.createElement('div');
            filterContainer.className = 'd-flex align-items-center gap-2 ms-auto';
            toolbar.append(filterContainer);

            // 1. Dropdown Fasilitas
            const selectTempat = document.createElement('select');
            selectTempat.id = 'filter-tempat';
            selectTempat.className = 'form-select form-select-sm';
            selectTempat.innerHTML = '<option value="all">Semua Fasilitas</option>';
            const uniqueTempat = [...new Set(allEvents.map(event => event.extendedProps.tempat))];
            uniqueTempat.forEach(tempat => {
                if(tempat) {
                    const option = document.createElement('option');
                    option.value = tempat;
                    option.textContent = tempat;
                    selectTempat.appendChild(option);
                }
            });
            filterContainer.appendChild(selectTempat);

            // 2. Dropdown Bulan
            const selectMonth = document.createElement('select');
            selectMonth.id = 'filter-month';
            selectMonth.className = 'form-select form-select-sm';
            const monthNames = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
            const currentMonth = calendar.getDate().getMonth();
            monthNames.forEach((month, index) => {
                const option = document.createElement('option');
                option.value = index;
                option.textContent = month;
                if (index === currentMonth) {
                    option.selected = true;
                }
                selectMonth.appendChild(option);
            });
            filterContainer.appendChild(selectMonth);

            // 3. Dropdown Tahun
            const selectYear = document.createElement('select');
            selectYear.id = 'filter-year';
            selectYear.className = 'form-select form-select-sm';
            const currentYear = calendar.getDate().getFullYear();
            const startYear = 2020; // Batas tahun awal
            const endYear = currentYear + 5; // Batas tahun akhir
            for (let year = startYear; year <= endYear; year++) {
                const option = document.createElement('option');
                option.value = year;
                option.textContent = year;
                if (year === currentYear) {
                    option.selected = true;
                }
                selectYear.appendChild(option);
            }
            filterContainer.appendChild(selectYear);

            // Tambahkan tombol Hari Ini
            const todayButton = document.createElement('button');
            todayButton.className = 'btn btn-primary btn-sm';
            todayButton.textContent = 'Hari Ini';
            todayButton.addEventListener('click', () => {
                calendar.today();
                // Sinkronkan dropdown dengan tanggal saat ini
                const newDate = calendar.getDate();
                selectMonth.value = newDate.getMonth();
                selectYear.value = newDate.getFullYear();
            });
            filterContainer.appendChild(todayButton);
            
            // Event listener untuk filter fasilitas
            selectTempat.addEventListener('change', () => {
                const tempatFilter = selectTempat.value;
                let filteredEvents;
                if (tempatFilter === 'all') {
                    filteredEvents = allEvents;
                } else {
                    filteredEvents = allEvents.filter(event => event.extendedProps.tempat === tempatFilter);
                }
                calendar.removeAllEvents();
                calendar.addEventSource(filteredEvents);
            });
            
            // Event listener untuk dropdown bulan dan tahun
            function updateCalendarDate() {
                const newMonth = parseInt(selectMonth.value);
                const newYear = parseInt(selectYear.value);
                calendar.gotoDate(new Date(newYear, newMonth, 1));
            }

            selectMonth.addEventListener('change', updateCalendarDate);
            selectYear.addEventListener('change', updateCalendarDate);

            // Sinkronkan dropdown saat kalender berpindah (misal dengan panah kiri/kanan)
            calendar.on('datesSet', function(info) {
                const newDate = info.view.calendar.getDate();
                selectMonth.value = newDate.getMonth();
                selectYear.value = newDate.getFullYear();
            });

            // Perbarui judul toolbar saat kalender pertama kali dimuat
            updateHeader(calendar, calendar.getDate().getFullYear(), calendar.getDate().getMonth());
        });
    </script>
</body>
</html>